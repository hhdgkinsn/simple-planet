// Themes
am4core.useTheme(am4themes_animated);

// Create map instance
var chart = am4core.create("map", am4maps.MapChart);

// Set map definition
chart.geodata = am4geodata_worldUltra;


// Set projection
chart.projection = new am4maps.projections.Miller();

// Zoom control
chart.zoomControl = new am4maps.ZoomControl();

// Reset Map
var homeButton = new am4core.Button();
homeButton.events.on("hit", function(){
  chart.goHome();
});

homeButton.icon = new am4core.Sprite();
homeButton.padding(7, 5, 7, 5);
homeButton.width = 30;
homeButton.icon.path = "M16,8 L14,8 L14,16 L10,16 L10,10 L6,10 L6,16 L2,16 L2,8 L0,8 L8,0 L16,8 Z M16,8";
homeButton.marginBottom = 10;
homeButton.parent = chart.zoomControl;
homeButton.insertBefore(chart.zoomControl.plusButton);

// Zoom level
chart.homeZoomLevel = 3;
chart.homeGeoPoint = { longitude: 16.5, latitude: 3.3 };


// Africa
var groupData = [
	{ "data": [{"id": "DZ", "url": "/africa/countries/algeria.html"}] },
	{ "data": [{"id": "AO", "url": "/africa/countries/angola.html"}] },
	{ "data": [{"id": "BJ", "url": "/africa/countries/benin.html"}] },
	{ "data": [{"id": "BW", "url": "/africa/countries/botswana.html"}] },
	{ "data": [{"id": "BF", "url": "/africa/countries/burkinafaso.html"}] },
	{ "data": [{"id": "BI", "url": "/africa/countries/burundi.html"}] },
	{ "data": [{"id": "CM", "url": "/africa/countries/cameroon.html"}] },
	{ "data": [{"id": "CV", "url": "/africa/countries/capeverde.html"}] },
	{ "data": [{"id": "CF", "url": "/africa/countries/car.html"}] },
	{ "data": [{"id": "KM", "url": "/africa/countries/comoros.html"}] },
	{ "data": [{"id": "CD", "url": "/africa/countries/congodrc.html"}] },
	{ "data": [{"id": "DJ", "url": "/africa/countries/djibouti.html"}] },
	{ "data": [{"id": "EG", "url": "/africa/countries/egypt.html"}] },
	{ "data": [{"id": "GQ", "url": "/africa/countries/equatorialguinea.html"}] },
	{ "data": [{"id": "ER", "url": "/africa/countries/eritrea.html"}] },
	{ "data": [{"id": "ET", "url": "/africa/countries/ethiopia.html"}] },
	{ "data": [{"id": "GA", "url": "/africa/countries/gabon.html"}] },
	{ "data": [{"id": "GM", "url": "/africa/countries/gambia.html"}] },
	{ "data": [{"id": "GH", "url": "/africa/countries/ghana.html"}] },
	{ "data": [{"id": "GN", "url": "/africa/countries/guinea.html"}] },
	{ "data": [{"id": "GW", "url": "/africa/countries/guineabissau.html"}] },,
	{ "data": [{"id": "CI", "url": "/africa/countries/cotedivoire.html"}] },
	{ "data": [{"id": "KE", "url": "/africa/countries/kenya.html"}] },
	{ "data": [{"id": "LS", "url": "/africa/countries/lesotho.html"}] },,
	{ "data": [{"id": "LR", "url": "/africa/countries/liberia.html"}] },
	{ "data": [{"id": "LY", "url": "/africa/countries/libya.html"}] },
	{ "data": [{"id": "MG", "url": "/africa/countries/madagascar.html"}] },
	{ "data": [{"id": "MW", "url": "/africa/countries/malawi.html"}] },
	{ "data": [{"id": "ML", "url": "/africa/countries/mali.html"}] },
	{ "data": [{"id": "MR", "url": "/africa/countries/mauritania.html"}] },
	{ "data": [{"id": "MU", "url": "/africa/countries/mauritius.html"}] },
	{ "data": [{"id": "MA", "url": "/africa/countries/morocco.html"}] },
	{ "data": [{"id": "MZ", "url": "/africa/countries/mozambique.html"}] },
	{ "data": [{"id": "NA", "url": "/africa/countries/namibia.html"}] },
	{ "data": [{"id": "NE", "url": "/africa/countries/niger.html"}] },,
	{ "data": [{"id": "NG", "url": "/africa/countries/nigeria.html"}] },
	{ "data": [{"id": "CG", "url": "/africa/countries/congo.html"}] },
	{ "data": [{"id": "RE"}] },
	{ "data": [{"id": "RW", "url": "/africa/countries/rwanda.html"}] },
	{ "data": [{"id": "SH", "url": "/africa/countries/sainthelena.html"}] },
	{ "data": [{"id": "ST", "url": "/africa/countries/saotomeprincipe.html"}] },
	{ "data": [{"id": "SN", "url": "/africa/countries/senegal.html"}] },
	{ "data": [{"id": "SC", "url": "/africa/countries/seychelles.html"}] },
	{ "data": [{"id": "SL", "url": "/africa/countries/sierraleone.html"}] },
	{ "data": [{"id": "SO", "url": "/africa/countries/somalia.html"}] },
	{ "data": [{"id": "ZA", "url": "/africa/countries/southafrica.html"}] },
	{ "data": [{"id": "SS"}] },
	{ "data": [{"id": "SD", "url": "/africa/countries/sudan.html"}] },
	{ "data": [{"id": "SZ", "url": "/africa/countries/eswatini.html"}] },
	{ "data": [{"id": "TZ", "url": "/africa/countries/tanzania.html"}] },
	{ "data": [{"id": "TG", "url": "/africa/countries/togo.html"}] },
	{ "data": [{"id": "TN", "url": "/africa/countries/tunisia.html"}] },
	{ "data": [{"id": "UG", "url": "/africa/countries/uganda.html"}] },
	{ "data": [{"id": "EH"}] },
	{ "data": [{"id": "YT"}] },
	{ "data": [{"id": "ZM", "url": "/africa/countries/zambia.html"}] },
	{ "data": [{"id": "ZW", "url": "/africa/countries/zimbabwe.html"}] },
	{ "data": [{"id": "TD", "url": "/africa/countries/chad.html"}] }
	];


var excludedCountries = ["AQ"];


groupData.forEach(function(group) {
  var series = chart.series.push(new am4maps.MapPolygonSeries());
  series.name = group.name;
  series.useGeodata = true;
  var includedCountries = [];
  group.data.forEach(function(country){
    includedCountries.push(country.id);
    excludedCountries.push(country.id);
  });
  series.include = includedCountries;

  series.fill = am4core.color("#fff");


  series.setStateOnChildren = true;
  var seriesHoverState = series.states.create("hover");


  var mapPolygonTemplate = series.mapPolygons.template;
  mapPolygonTemplate.fill = am4core.color("#a1d47f");
  mapPolygonTemplate.fillOpacity = 1;
  mapPolygonTemplate.nonScalingStroke = true;
  mapPolygonTemplate.stroke = am4core.color("#000");
  mapPolygonTemplate.strokeWidth = 0.2;
  mapPolygonTemplate.strokeOpacity = 0.5;
  mapPolygonTemplate.tooltipText = "{name}";
  mapPolygonTemplate.propertyFields.url = "url";


  var hoverState = mapPolygonTemplate.states.create("hover");
  hoverState.properties.fill = am4core.color("#8ec16c");

  series.data = JSON.parse(JSON.stringify(group.data));

});


// The rest of the world.
var worldSeries = chart.series.push(new am4maps.MapPolygonSeries());
var worldSeriesName = "world";
worldSeries.name = worldSeriesName;
worldSeries.fill = am4core.color("#fff");
worldSeries.fillOpacity = 1;
worldSeries.useGeodata = true;
worldSeries.exclude = excludedCountries;
worldSeries.mapPolygons.template.nonScalingStroke = true;

worldSeries.mapPolygons.template.stroke = worldSeries.mapPolygons.template.fill;
worldSeries.mapPolygons.template.strokeWidth = 0;
