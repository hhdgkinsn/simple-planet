var africaDataApp = angular.module('africaDataApp', []);

africaDataApp.controller('africa-info', function($scope) {
  $scope.info = [
    {key:"Size", value:"30,370,000 km2"},
    {key:"Population", value:"1.3 bil"},
    {key:"Number of countries", value:"54"},
    {key:"Largest Country", value:"Algeria"},
    {key:"Smallest Country", value:"Seychelles"},
    {key:"Most populated country", value:"Nigeria"},
    {key:"Most Populated City", value:"Lagos, Nigeria"},
    {key:"Highest Point", value:"Mount Kilimanjaro, Tanzania"}
   ];
});

africaDataApp.controller('algeria-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"People's Democratic Republic of Algeria"},
    {key:"Size", value:"2.382 million km²"},
    {key:"Population", value:"41.32 million (2019)"},
    {key:"Capital", value:"Algiers"},
    {key:"Official Language(s)", value:"Arabic"},
    {key:"Government", value:"Semi-presidential"},
    {key:"President", value:"Abdelmadjid Tebboune"},
    {key:"Prime Minister", value:"Abdelaziz Djerad"},
    {key:"GDP", value:"$684.649 billion (2019)"},
    {key:"Currency", value:"Dinar"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+213"},
    {key:"ISO 3166 code", value:"DZ"},
    {key:"Internal TLD", value:".dz"}
   ];
});

africaDataApp.controller('angola-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Angola"},
    {key:"Size", value:"1.247 million km²"},
    {key:"Population", value:"29.78 million (2017)"},
    {key:"Capital", value:"Luanda"},
    {key:"Official Language(s)", value:"	Portuguese"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"	João Manuel Gonçalves Lourenço"},
    {key:"Vice President", value:"Bornito de Sousa"},
    {key:"GDP", value:"$208.034 billion (2019)"},
    {key:"Currency", value:"Kwanza (AOA)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+244"},
    {key:"ISO 3166 code", value:"AO"},
    {key:"Internal TLD", value:".ao"}
   ];
});

africaDataApp.controller('benin-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Benin"},
    {key:"Size", value:"114,763 km²"},
    {key:"Population", value:"11.48 million (2018)"},
    {key:"Capital", value:"Porto-Novo"},
    {key:"Official Language(s)", value:"French"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"Patrice Talon"},
    {key:"GDP", value:"	$29.918 billion (2019)"},
    {key:"Currency", value:"West African CFA franc (XOF)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+229"},
    {key:"ISO 3166 code", value:"BJ"},
    {key:"Internal TLD", value:".bj"}
   ];
});

africaDataApp.controller('botswana-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Botswana"},
    {key:"Size", value:"114,763 km²"},
    {key:"Population", value:"2.292 million (2017)"},
    {key:"Capital", value:"Gaborone"},
    {key:"Official Language(s)", value:"English, Setswana"},
    {key:"Government", value:"Parliamentary"},
    {key:"President", value:"	Mokgweetsi Masisi"},
    {key:"Vice President", value:"Slumber Tsogwane"},
    {key:"GDP", value:"	$44.3 billion (2019)"},
    {key:"Currency", value:"Botswana pula (BWP)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+267"},
    {key:"ISO 3166 code", value:"BW"},
    {key:"Internal TLD", value:".bw"}
   ];
});

africaDataApp.controller('burkinafaso-info', function($scope) {
  $scope.info = [
    {key:"Size", value:"274,200 km²"},
    {key:"Population", value:"19.19 million (2017)"},
    {key:"Capital", value:"Ouagadougou"},
    {key:"Official Language(s)", value:"French"},
    {key:"Government", value:"Semi-presidential"},
    {key:"President", value:"	Roch Marc Christian Kaboré"},
    {key:"Prime minister", value:"Christophe Joseph Marie Dabiré"},
    {key:"GDP", value:"	$45.339 billion (2020)"},
    {key:"Currency", value:"	West African CFA franc (XOF)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+226"},
    {key:"ISO 3166 code", value:"BF"},
    {key:"Internal TLD", value:".bf"}
   ];
});

africaDataApp.controller('burundi-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Burundi"},
    {key:"Size", value:"274,200 km²"},
    {key:"Population", value:"19.19 million (2017)"},
    {key:"Capital", value:"Ouagadougou"},
    {key:"Official Language(s)", value:"French"},
    {key:"Government", value:"Semi-presidential"},
    {key:"President", value:"	Roch Marc Christian Kaboré"},
    {key:"Prime minister", value:"Christophe Joseph Marie Dabiré"},
    {key:"GDP", value:"	$45.339 billion (2020)"},
    {key:"Currency", value:"	West African CFA franc (XOF)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+226"},
    {key:"ISO 3166 code", value:"BF"},
    {key:"Internal TLD", value:".bf"}
   ];
});

africaDataApp.controller('cameroon-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Cameroon"},
    {key:"Size", value:"475,442 km²"},
    {key:"Population", value:"25.21 million (2018)"},
    {key:"Capital", value:"Yaoundé"},
    {key:"Official Language(s)", value:"English, French"},
    {key:"Government", value:"Semi-presidential"},
    {key:"President", value:"Paul Biya"},
    {key:"Prime minister", value:"Joseph Ngute"},
    {key:"GDP", value:"	$95.068 billion (2018)"},
    {key:"Currency", value:"Central African CFA franc (XAF)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+237"},
    {key:"ISO 3166 code", value:"CM"},
    {key:"Internal TLD", value:".cm"}
   ];
});

africaDataApp.controller('capeverde-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Cabo Verde"},
    {key:"Size", value:"4,033 km²"},
    {key:"Population", value:"546,388 (2017)"},
    {key:"Capital", value:"Praia"},
    {key:"Official Language(s)", value:"Portuguese"},
    {key:"Government", value:"Semi-presidential"},
    {key:"President", value:"	Jorge Carlos Fonseca"},
    {key:"Prime minister", value:"Ulisses Correia e Silva"},
    {key:"GDP", value:"	$4.323 billion (2019)"},
    {key:"Currency", value:"	Cape Verdean escudo (CVE)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+238"},
    {key:"ISO 3166 code", value:"CV"},
    {key:"Internal TLD", value:".cv"}
   ];
});

africaDataApp.controller('car-info', function($scope) {
  $scope.info = [
    {key:"Size", value:"622,984 km²"},
    {key:"Population", value:"4.66 million (2017)"},
    {key:"Capital", value:"Bangui"},
    {key:"Official Language(s)", value:"French, Sango"},
    {key:"Government", value:"Semi-presidential"},
    {key:"President", value:"Faustin-Archange Touadéra"},
    {key:"Prime minister", value:"Firmin Ngrébada"},
    {key:"GDP", value:"$3.454 billion (2017)"},
    {key:"Currency", value:"	Central African CFA franc (XAF)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+236"},
    {key:"ISO 3166 code", value:"CF"},
    {key:"Internal TLD", value:".cf"}
   ];
});

africaDataApp.controller('chad-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Chad"},
    {key:"Size", value:"1,284,000 km2"},
    {key:"Population", value:"14.9 million (2017)"},
    {key:"Capital", value:"N'Djamena"},
    {key:"Official Language(s)", value:"Arabic, French"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"Idriss Déby"},
    {key:"GDP", value:"$30 billion (2018)"},
    {key:"Currency", value:"Central African CFA franc (XAF)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+235"},
    {key:"ISO 3166 code", value:"TD"},
    {key:"Internal TLD", value:".td"}
   ];
});

africaDataApp.controller('comoros-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Union of the Comoros"},
    {key:"Size", value:"1,659 km²"},
    {key:"Population", value:"813.91 (2017)"},
    {key:"Capital", value:"Moroni"},
    {key:"Official Language(s)", value:"Comorian, Arabic, French"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"	Azali Assoumani"},
    {key:"GDP", value:"$2.446 billion (2019)"},
    {key:"Currency", value:"Comorian franc (KMF)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+269"},
    {key:"ISO 3166 code", value:"KM"},
    {key:"Internal TLD", value:".km"}
   ];
});

africaDataApp.controller('congodrc-info', function($scope) {
  $scope.info = [
    {key:"Size", value:"2.345 million km²"},
    {key:"Population", value:"81.34 million (2017)"},
    {key:"Capital", value:"Kinshasa"},
    {key:"Official Language(s)", value:"French"},
    {key:"Government", value:"Semi-presidential"},
    {key:"President", value:"Félix Tshisekedi"},
    {key:"Prime minister", value:"Sylvestre Ilunga"},
    {key:"GDP", value:"$156.886 billion (2019)"},
    {key:"Currency", value:"Congolese franc (CDF)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+243"},
    {key:"ISO 3166 code", value:"CD"},
    {key:"Internal TLD", value:".cd"}
   ];
});

africaDataApp.controller('congo-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of the Congo"},
    {key:"Size", value:"342,000 km²"},
    {key:"Population", value:"5.261 million (2017)"},
    {key:"Capital", value:"Brazzaville"},
    {key:"Official Language(s)", value:"French"},
    {key:"Government", value:"Semi-presidential"},
    {key:"President", value:"Denis Sassou Nguesso"},
    {key:"Prime minister", value:"Clément Mouamba"},
    {key:"GDP", value:"$32.516 billion (2019)"},
    {key:"Currency", value:"Central African CFA franc (XAF)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+242"},
    {key:"ISO 3166 code", value:"CG"},
    {key:"Internal TLD", value:".cg"}
   ];
});

africaDataApp.controller('cotedivoire-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Côte d'Ivoire"},
    {key:"Size", value:"322,463 km²"},
    {key:"Population", value:"24.29 million (2017)"},
    {key:"Capital", value:"Yamoussoukro"},
    {key:"Official Language(s)", value:"French"},
    {key:"Government", value:"Presidential, Parliamentary"},
    {key:"President", value:"Alassane Ouattara"},
    {key:"Vice president", value:"Daniel Kablan Duncan"},
    {key:"Prime minister", value:"Amadou Gon Coulibaly"},
    {key:"GDP", value:"$126.863 billion (2020)"},
    {key:"Currency", value:"West African CFA franc (XOF)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+225"},
    {key:"ISO 3166 code", value:"CI"},
    {key:"Internal TLD", value:".ci"}
   ];
});

africaDataApp.controller('djibouti-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Djibouti"},
    {key:"Size", value:"23,200 km2"},
    {key:"Population", value:"884,017 (2018)"},
    {key:"Capital", value:"Djibouti"},
    {key:"Official Language(s)", value:"Arabic, French"},
    {key:"Government", value:"Presidential, Dictatorship"},
    {key:"President", value:"Ismaïl Omar Guelleh"},
    {key:"Prime minister", value:"Abdoulkader Kamil Mohamed"},
    {key:"GDP", value:"$3.974 billion (2018)"},
    {key:"Currency", value:"Djiboutian franc (DJF)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+253"},
    {key:"ISO 3166 code", value:"DJ"},
    {key:"Internal TLD", value:".dj"}
   ];
});

africaDataApp.controller('egypt-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Arab Republic of Egypt"},
    {key:"Size", value:"1,010,408 km2"},
    {key:"Population", value:"100 million (2020)"},
    {key:"Capital", value:"Cairo"},
    {key:"Official Language(s)", value:"Arabic"},
    {key:"Government", value:"Semi-presidential"},
    {key:"President", value:"Abdel Fattah el-Sisi"},
    {key:"Prime minister", value:"Mostafa Madbouly"},
    {key:"GDP", value:"$1.391 trillion (2019)"},
    {key:"Currency", value:"Egyptian pound (EGP)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+20"},
    {key:"ISO 3166 code", value:"EG"},
    {key:"Internal TLD", value:".eg"}
   ];
});

africaDataApp.controller('equatorialguinea-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Equatorial Guinea"},
    {key:"Size", value:"1,010,408 km2"},
    {key:"Population", value:"1.3 million (2018)"},
    {key:"Capital", value:"Cairo"},
    {key:"Official Language(s)", value:"Spanish, French, Portuguese"},
    {key:"Government", value:"Presidential, Dictatorship"},
    {key:"President", value:"Teodoro Obiang Nguema Mbasogo"},
    {key:"First vice-president", value:"Teodoro Nguema Obiang Mangue"},
    {key:"Prime minister", value:"Francisco Pascual Obama Asue"},
    {key:"GDP", value:"$29.162 billion (2019)"},
    {key:"Currency", value:"Central African CFA franc (XAF)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+240"},
    {key:"ISO 3166 code", value:"GQ"},
    {key:"Internal TLD", value:".gq"}
   ];
});

africaDataApp.controller('eritrea-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"State of Eritrea"},
    {key:"Size", value:"117,600 km2"},
    {key:"Population", value:"5.75 million (2018)"},
    {key:"Capital", value:"Asmara"},
    {key:"Language(s)", value:"Tigrinya, Arabic, English"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"Isaias Afwerki"},
    {key:"GDP", value:"$10.625 billion (2019)"},
    {key:"Currency", value:"Nakfa (ERN)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+291"},
    {key:"ISO 3166 code", value:"ER"},
    {key:"Internal TLD", value:".er"}
   ];
});

africaDataApp.controller('eswatini-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Kingdom of Eswatini"},
    {key:"Size", value:"17,364 km2"},
    {key:"Population", value:"1.13 million (2018)"},
    {key:"Capital", value:"Mbabane"},
    {key:"Official Language(s)", value:"Swazi, English"},
    {key:"Government", value:"Parliamentary, Monarchy"},
    {key:"Monarch", value:"Mswati III"},
    {key:"Prime minister", value:"Ambrose Dlamini"},
    {key:"GDP", value:"$4.662 billion (2019)"},
    {key:"Currency", value:"Swazi lilangeni (SZL), South African rand (ZAR)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+268"},
    {key:"ISO 3166 code", value:"SZ"},
    {key:"Internal TLD", value:".sz"}
   ];
});

africaDataApp.controller('ethiopia-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Federal Democratic Republic of Ethiopia"},
    {key:"Size", value:"1,104,300"},
    {key:"Population", value:"109.22 million (2018)"},
    {key:"Capital", value:"Addis Ababa"},
    {key:"Official Language(s)", value:"Amharic"},
    {key:"Government", value:"Parliamentary"},
    {key:"President", value:"Sahle-Work Zewde"},
    {key:"Prime minister", value:"Abiy Ahmed Ali"},
    {key:"GDP", value:"$240.168 billion (2019)"},
    {key:"Currency", value:"Birr (ETB)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+251"},
    {key:"ISO 3166 code", value:"ET"},
    {key:"Internal TLD", value:".et"}
   ];
});

africaDataApp.controller('gabon-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Gabonese Republic"},
    {key:"Size", value:"267,667 km2"},
    {key:"Population", value:"2.11 million (2018)"},
    {key:"Capital", value:"Libreville"},
    {key:"Language(s)", value:"French"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"Ali Bongo Ondimba"},
    {key:"Prime minister", value:"Julien Nkoghe Bekale"},
    {key:"GDP", value:"$38.280 billion (2018)"},
    {key:"Currency", value:"Central African CFA franc (XAF)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+241"},
    {key:"ISO 3166 code", value:"GA"},
    {key:"Internal TLD", value:".ga"}
   ];
});

africaDataApp.controller('ghana-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Ghana"},
    {key:"Size", value:"239,567 km2 "},
    {key:"Population", value:"28.3 million (2016)"},
    {key:"Capital", value:"Accra"},
    {key:"Official Language(s)", value:"English"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"Nana Akufo-Addo"},
    {key:"Vice President", value:"Mahamudu Bawumia"},
    {key:"GDP", value:"$211.127 billion (2019)"},
    {key:"Currency", value:"Ghanaian cedi (GHS)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+233"},
    {key:"ISO 3166 code", value:"GH"},
    {key:"Internal TLD", value:".gh"}
   ];
});

africaDataApp.controller('guinea-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Guinea"},
    {key:"Size", value:"245,857 km2"},
    {key:"Population", value:"12.41 million (2018)"},
    {key:"Capital", value:"Conakry"},
    {key:"Official Language(s)", value:"French"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"Alpha Condé"},
    {key:"Vice President", value:"	Ibrahima Kassory Fofana"},
    {key:"GDP", value:"$26.451 billion (2017)"},
    {key:"Currency", value:"Guinean franc (GNF)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+224"},
    {key:"ISO 3166 code", value:"GN"},
    {key:"Internal TLD", value:".gn"}
   ];
});

africaDataApp.controller('guineabissau-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Guinea-Bissau"},
    {key:"Size", value:"36,125 km2"},
    {key:"Population", value:"1.87 million (2018)"},
    {key:"Capital", value:"Bissau"},
    {key:"Official Language(s)", value:"Portuguese"},
    {key:"Government", value:"Semi-presidential"},
    {key:"President", value:"	José Mário Vaz"},
    {key:"Vice President", value:"Aristides Gomes"},
    {key:"GDP", value:"$3.391 billion (2018)"},
    {key:"Currency", value:"West African CFA franc (XOF)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+245"},
    {key:"ISO 3166 code", value:"GW"},
    {key:"Internal TLD", value:".gw"}
   ];
});

africaDataApp.controller('kenya-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Kenya"},
    {key:"Size", value:"580,367 km2"},
    {key:"Population", value:"47.56 million (2019)"},
    {key:"Capital", value:"Nairobi"},
    {key:"Official Language(s)", value:"English, Swahili"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"Uhuru Kenyatta"},
    {key:"GDP", value:"$190.182 billion (2019)"},
    {key:"Currency", value:"Kenyan shilling (KES)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+254"},
    {key:"ISO 3166 code", value:"KE"},
    {key:"Internal TLD", value:".ke"}
   ];
});

africaDataApp.controller('lesotho-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Kingdom of Lesotho"},
    {key:"Size", value:"30,355 km2"},
    {key:"Population", value:"2.10 million (2018)"},
    {key:"Capital", value:"Maseru"},
    {key:"Official Language(s)", value:"Sesotho, English"},
    {key:"Government", value:"Parliamentary, Monarchy"},
    {key:"Monarch", value:"Letsie III"},
    {key:"Prime minister", value:"Tom Thabane"},
    {key:"GDP", value:"$2.721 billion (2017)"},
    {key:"Currency", value:"Lesotho loti (LSL), South African rand (ZAR)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+266"},
    {key:"ISO 3166 code", value:"LS"},
    {key:"Internal TLD", value:".ls"}
   ];
});

africaDataApp.controller('liberia-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Liberia"},
    {key:"Size", value:"111,369 km2"},
    {key:"Population", value:"4.8 million (2015)"},
    {key:"Capital", value:"Monrovia"},
    {key:"Official Language(s)", value:"English"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"George Weah"},
    {key:"Vice-president", value:"Jewel Taylor"},
    {key:"GDP", value:"	$6.468 billion (2019)"},
    {key:"Currency", value:"Liberian dollar (LRD)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+231"},
    {key:"ISO 3166 code", value:"LR"},
    {key:"Internal TLD", value:".lr"}
   ];
});

africaDataApp.controller('libya-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"State of Libya"},
    {key:"Size", value:"1,759,541 km2"},
    {key:"Population", value:"6.65 million (2018)"},
    {key:"Capital", value:"Tripoli"},
    {key:"Official Language(s)", value:"Arabic"},
    {key:"Government", value:"Provisional"},
    {key:"Prime minister", value:"Fayez al-Sarraj"},
    {key:"GDP", value:"$79.595 billion (2019)"},
    {key:"Currency", value:"Libyan dinar (LYD)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+218"},
    {key:"ISO 3166 code", value:"LY"},
    {key:"Internal TLD", value:".ly"}
   ];
});

africaDataApp.controller('madagascar-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Madagascar"},
    {key:"Size", value:"587,041 km2"},
    {key:"Population", value:"26.26 million (2018)"},
    {key:"Capital", value:"Antananarivo"},
    {key:"Official Language(s)", value:"Malagasy, French"},
    {key:"Government", value:"Semi-presidential"},
    {key:"President", value:"Andry Rajoelina"},
    {key:"Prime minister", value:"Christian Ntsay"},
    {key:"GDP", value:"$45.948 billion (2019)"},
    {key:"Currency", value:"Malagasy ariary (MGA)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+261"},
    {key:"ISO 3166 code", value:"MG"},
    {key:"Internal TLD", value:".mg"}
   ];
});

africaDataApp.controller('malawi-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Malawi"},
    {key:"Size", value:"118,484 km2"},
    {key:"Population", value:"18.14 million (2018)"},
    {key:"Capital", value:"Lilongwe"},
    {key:"Official Language(s)", value:"English, Chichewa"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"	Peter Mutharika"},
    {key:"Vice-president", value:"Saulos Chilima"},
    {key:"GDP", value:"$25.037 billion (2019)"},
    {key:"Currency", value:"Kwacha (D) (MWK)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+265"},
    {key:"ISO 3166 code", value:"MW"},
    {key:"Internal TLD", value:".mw"}
   ];
});

africaDataApp.controller('mali-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Mali"},
    {key:"Size", value:"1,240,192 km2"},
    {key:"Population", value:"19.32 million (2018)"},
    {key:"Capital", value:"Bamako"},
    {key:"Official Language(s)", value:"French"},
    {key:"Government", value:"Semi-presidential"},
    {key:"President", value:"Ibrahim Boubacar Keïta"},
    {key:"Prime minister", value:"Boubou Cisse"},
    {key:"GDP", value:"$17.407 billion (2018)"},
    {key:"Currency", value:"West African CFA franc (XOF)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+223"},
    {key:"ISO 3166 code", value:"ML"},
    {key:"Internal TLD", value:".ml"}
   ];
});

africaDataApp.controller('mauritania-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Islamic Republic of Mauritania"},
    {key:"Size", value:"1,030,000 km2"},
    {key:"Population", value:"4.4 million (2018)"},
    {key:"Capital", value:"Nouakchott"},
    {key:"Official Language(s)", value:"Arabic"},
    {key:"Government", value:"Semi-presidential"},
    {key:"President", value:"Mohamed Ould Ghazouani"},
    {key:"Prime minister", value:"Ismail Ould Bedde Ould Cheikh Sidiya"},
    {key:"GDP", value:"$18.117 billion (2018)"},
    {key:"Currency", value:"Ouguiya (MRU)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+222"},
    {key:"ISO 3166 code", value:"MR"},
    {key:"Internal TLD", value:".mr"}
   ];
});

africaDataApp.controller('mauritius-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Mauritius"},
    {key:"Size", value:"2,040 km2"},
    {key:"Population", value:"1.26 million (2018)"},
    {key:"Capital", value:"Port Louis"},
    {key:"Official Language(s)", value:"Arabic"},
    {key:"Government", value:"Parliamentary"},
    {key:"President", value:"Pradeep Roopun"},
    {key:"Prime minister", value:"Pravind Jugnauth"},
    {key:"GDP", value:"$31.705 billion (2019)"},
    {key:"Currency", value:"Mauritian rupee (MUR)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+230"},
    {key:"ISO 3166 code", value:"MU"},
    {key:"Internal TLD", value:".mu"}
   ];
});

africaDataApp.controller('morocco-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Kingdom of Morocco"},
    {key:"Size", value:"710,850 km2"},
    {key:"Population", value:"35.58 million (2017)"},
    {key:"Capital", value:"Rabat"},
    {key:"Official Language(s)", value:"Arabic, Berber"},
    {key:"Government", value:"Parliamentary, Monarchy"},
    {key:"Monarchy", value:"	Mohammed VI"},
    {key:"Prime minister", value:"Saadeddine Othmani"},
    {key:"GDP", value:"$332.358 billion (2019)"},
    {key:"Currency", value:"Moroccan dirham (MAD)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+212"},
    {key:"ISO 3166 code", value:"MA"},
    {key:"Internal TLD", value:".ma"}
   ];
});


africaDataApp.controller('mozambique-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Mozambique"},
    {key:"Size", value:"801,590 km2"},
    {key:"Population", value:"29.49 million (2018)"},
    {key:"Capital", value:"Maputo"},
    {key:"Official Language(s)", value:"Portuguese"},
    {key:"Government", value:"Semi-presidential"},
    {key:"President", value:"Filipe Nyusi"},
    {key:"Prime minister", value:"Carlos Agostinho do Rosário"},
    {key:"GDP", value:"$41.473 billion (2019)"},
    {key:"Currency", value:"Mozambican metical (MZN)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+258"},
    {key:"ISO 3166 code", value:"MZ"},
    {key:"Internal TLD", value:".mz"}
   ];
});

africaDataApp.controller('namibia-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Namibia"},
    {key:"Size", value:"825,615 km2"},
    {key:"Population", value:"2.6 million (2017)"},
    {key:"Capital", value:"Windhoek"},
    {key:"Official Language(s)", value:"English"},
    {key:"Government", value:"Semi-presidential"},
    {key:"President", value:"	Hage Geingob"},
    {key:"Vice-president", value:"Nangolo Mbumba"},
    {key:"Prime minister", value:"Saara Kuugongelwa-Amadhila"},
    {key:"GDP", value:"$41.473 billion (2019)"},
    {key:"Currency", value:"Namibian dollar (NAD), South African rand (ZAR)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+264"},
    {key:"ISO 3166 code", value:"NA"},
    {key:"Internal TLD", value:".na"}
   ];
});

africaDataApp.controller('niger-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of the Niger"},
    {key:"Size", value:"1,267,000 km2"},
    {key:"Population", value:"22.44 million (2018)"},
    {key:"Capital", value:"Niamey"},
    {key:"Official Language(s)", value:"French"},
    {key:"Government", value:"Semi-presidential"},
    {key:"President", value:"Mahamadou Issoufou"},
    {key:"Prime minister", value:"Brigi Rafini"},
    {key:"GDP", value:"$23.475 billion (2018)"},
    {key:"Currency", value:"West African CFA franc (XOF)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+227"},
    {key:"ISO 3166 code", value:"NE"},
    {key:"Internal TLD", value:".ne"}
   ];
});

africaDataApp.controller('nigeria-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Federal Republic of Nigeria"},
    {key:"Size", value:"923,768 km2"},
    {key:"Population", value:"200.96 million (2019)"},
    {key:"Capital", value:"Abuja"},
    {key:"Official Language(s)", value:"English"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"Muhammadu Buhari"},
    {key:"Vice president", value:"Yemi Osinbajo"},
    {key:"GDP", value:"$1.221 trillion (2019)"},
    {key:"Currency", value:"Naira (NGN)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+234"},
    {key:"ISO 3166 code", value:"NG"},
    {key:"Internal TLD", value:".ng"}
   ];
});

africaDataApp.controller('rwanda-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Rwanda"},
    {key:"Size", value:"26,338 km2"},
    {key:"Population", value:"11.26 million (2015)"},
    {key:"Capital", value:"Kigali"},
    {key:"Official Language(s)", value:"English, French, Kinyarwanda, Swahili"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"	Paul Kagame"},
    {key:"Prime minister", value:"Édouard Ngirente"},
    {key:"GDP", value:"	$30.068 billion (2019)"},
    {key:"Currency", value:"Rwandan franc (RWF)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+250"},
    {key:"ISO 3166 code", value:"RW"},
    {key:"Internal TLD", value:".rw"}
   ];
});

africaDataApp.controller('sainthelena-info', function($scope) {
  $scope.info = [
    {key:"Sovereign state", value:"United Kingdom"},
    {key:"Size", value:"121 km2"},
    {key:"Population", value:"4,534 (2016)"},
    {key:"Capital", value:"Jamestown"},
    {key:"Official Language(s)", value:"English"},
    {key:"Government", value:"Parliamentary, Monarchy"},
    {key:"Monarch", value:"Elizabeth II"},
    {key:"Governor", value:"Philip Rushbrook"},
    {key:"Currency", value:"Saint Helena pound (SHP)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+290"},
    {key:"ISO 3166 code", value:"SH"},
    {key:"Internal TLD", value:".sh"}
   ];
});

africaDataApp.controller('saotomeprincipe-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Democratic Republic of São Tomé and Príncipe"},
    {key:"Size", value:"1,001 km2"},
    {key:"Population", value:"211,028 (2018)"},
    {key:"Capital", value:"São Tomé"},
    {key:"Official Language(s)", value:"Portuguese"},
    {key:"Government", value:"Semi-presidential"},
    {key:"President", value:"Evaristo Carvalho"},
    {key:"Prime minister", value:"Jorge Bom Jesus"},
    {key:"GDP", value:"$685 million (2017)"},
    {key:"Currency", value:"Dobra (STN)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+239"},
    {key:"ISO 3166 code", value:"ST"},
    {key:"Internal TLD", value:".st"}
   ];
});

africaDataApp.controller('senegal-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Senegal"},
    {key:"Size", value:"196,712 km2"},
    {key:"Population", value:"15.85 million (2018)"},
    {key:"Capital", value:"Dakar"},
    {key:"Official Language(s)", value:"French, Wolof"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"	Macky Sall"},
    {key:"GDP", value:"	$59.987 billion (2018)"},
    {key:"Currency", value:"West African CFA franc (XOF)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+221"},
    {key:"ISO 3166 code", value:"SN"},
    {key:"Internal TLD", value:".sn"}
   ];
});

africaDataApp.controller('seychelles-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Seychelles"},
    {key:"Size", value:"459 km2"},
    {key:"Population", value:"	97,096 (2018)"},
    {key:"Capital", value:"Victoria"},
    {key:"Official Language(s)", value:"English, French, Seychellois Creole"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"Danny Faure"},
    {key:"Vice-president", value:"Vincent Mériton"},
    {key:"GDP", value:"$2.919 billion (2018)"},
    {key:"Currency", value:"Seychellois rupee (SCR)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+248"},
    {key:"ISO 3166 code", value:"SC"},
    {key:"Internal TLD", value:".sc"}
   ];
});

africaDataApp.controller('sierraleone-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Sierra Leone"},
    {key:"Size", value:"71,740 km2"},
    {key:"Population", value:"7.07 million (2015)"},
    {key:"Capital", value:"Freetown"},
    {key:"Official Language(s)", value:"English"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"Julius Maada Bio"},
    {key:"Vice-president", value:"Mohamed Juldeh Jalloh"},
    {key:"GDP", value:"$12.177 billion (2018)"},
    {key:"Currency", value:"Leone (SLL)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+232"},
    {key:"ISO 3166 code", value:"SL"},
    {key:"Internal TLD", value:".sl"}
   ];
});

africaDataApp.controller('somalia-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Federal Republic of Somalia"},
    {key:"Size", value:"637,657 km2"},
    {key:"Population", value:"11.03 million (2017)"},
    {key:"Capital", value:"Mogadishu"},
    {key:"Official Language(s)", value:"Somali, Arabic"},
    {key:"Government", value:"Parliamentary"},
    {key:"President", value:"	Mohamed Abdullahi Mohamed"},
    {key:"Prime minister", value:"Hassan Ali Khayre"},
    {key:"GDP", value:"$22.1 billion (2018)"},
    {key:"Currency", value:"Somali shilling (SOS)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+252"},
    {key:"ISO 3166 code", value:"SO"},
    {key:"Internal TLD", value:".so"}
   ];
});

africaDataApp.controller('southafrica-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of South Africa"},
    {key:"Size", value:"1,221,037 km2"},
    {key:"Population", value:"58.77 million (2019)"},
    {key:"Capital", value:"Pretoria"},
    {key:"Official Language(s)", value:"English, Afrikaans, Zulu"},
    {key:"Government", value:"Parliamentary, Executive presidency"},
    {key:"President", value:"Cyril Ramaphosa"},
    {key:"Deputy president", value:"David Mabuza"},
    {key:"GDP", value:"$813.100 billion (2019)"},
    {key:"Currency", value:"South African rand (ZAR)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+27"},
    {key:"ISO 3166 code", value:"ZA"},
    {key:"Internal TLD", value:".za"}
   ];
});

africaDataApp.controller('sudan-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of the Sudan"},
    {key:"Size", value:"1,886,068 km2"},
    {key:"Population", value:"41.59 million (2019)"},
    {key:"Capital", value:"Khartoum"},
    {key:"Official Language(s)", value:"Arabic"},
    {key:"Government", value:"Parliamentary, Provisional"},
    {key:"Sovereignty council", value:"Abdel Fattah al-Burhan"},
    {key:"GDP", value:"$177.678 billion (2018)"},
    {key:"Currency", value:"Sudanese pound (SDG)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+249"},
    {key:"ISO 3166 code", value:"SD"},
    {key:"Internal TLD", value:".sd"}
   ];
});

africaDataApp.controller('tanzania-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"United Republic of Tanzania"},
    {key:"Size", value:"947,303 km2"},
    {key:"Population", value:"56.31 million (2018)"},
    {key:"Capital", value:"Dodoma"},
    {key:"Official Language(s)", value:"Swahili"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"John Magufuli"},
    {key:"Vice-president", value:"Samia Hassan Suluhu"},
    {key:"Prime minister", value:"Kassim Majaliwa"},
    {key:"GDP", value:"$186.060 billion (2019)"},
    {key:"Currency", value:"Tanzanian shilling (TZS)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+255"},
    {key:"ISO 3166 code", value:"TZ"},
    {key:"Internal TLD", value:".tz"}
   ];
});

africaDataApp.controller('thegambia-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of The Gambia"},
    {key:"Size", value:"267,667 km2"},
    {key:"Population", value:"2.05 million (2017)"},
    {key:"Capital", value:"Banjul"},
    {key:"Official Language(s)", value:"English"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"	Adama Barrow"},
    {key:"Vice President", value:"Isatou Touray"},
    {key:"GDP", value:"$3.582 billion (2017)"},
    {key:"Currency", value:"Dalasi (GMD)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+220"},
    {key:"ISO 3166 code", value:"GM"},
    {key:"Internal TLD", value:".gm"}
   ];
});

africaDataApp.controller('togo-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Togolese Republic"},
    {key:"Size", value:"56,785 km2"},
    {key:"Population", value:"7.96 million (2017)"},
    {key:"Capital", value:"Lomé"},
    {key:"Official Language(s)", value:"French"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"	Faure Gnassingbé"},
    {key:"Prime minister", value:"Komi Sélom Klassou"},
    {key:"GDP", value:"$14.919 billion (2019)"},
    {key:"Currency", value:"West African CFA franc (XOF)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+228"},
    {key:"ISO 3166 code", value:"TG"},
    {key:"Internal TLD", value:".tg"}
   ];
});

africaDataApp.controller('tunisia-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Tunisia"},
    {key:"Size", value:"163,610 km2"},
    {key:"Population", value:"11.43 million (2017)"},
    {key:"Capital", value:"Tunis"},
    {key:"Official Language(s)", value:"Arabic"},
    {key:"Government", value:"Semi-presidential"},
    {key:"President", value:"Kais Saied"},
    {key:"Prime minister", value:"Youssef Chahed"},
    {key:"GDP", value:"$151.566 billion (2019)"},
    {key:"Currency", value:"Tunisian dinar (TND)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+216"},
    {key:"ISO 3166 code", value:"TN"},
    {key:"Internal TLD", value:".tn"}
   ];
});

africaDataApp.controller('uganda-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Uganda"},
    {key:"Size", value:"241,038 km2"},
    {key:"Population", value:"43.72 million (2018)"},
    {key:"Capital", value:"Kampala"},
    {key:"Official Language(s)", value:"English, Swahili"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"Yoweri Museveni"},
    {key:"Vice-president", value:"Edward Ssekandi"},
    {key:"Prime minister", value:"Ruhakana Rugunda"},
    {key:"GDP", value:"$30.765 billion (2019)"},
    {key:"Currency", value:"Ugandan shilling (UGX)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+256"},
    {key:"ISO 3166 code", value:"UG"},
    {key:"Internal TLD", value:".ug"}
   ];
});

africaDataApp.controller('zambia-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Zambia"},
    {key:"Size", value:"752,618 km2 "},
    {key:"Population", value:"17.35 million (2018)"},
    {key:"Capital", value:"Lusaka"},
    {key:"Official Language(s)", value:"English"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"	Edgar Lungu"},
    {key:"Vice-president", value:"Inonge Wina"},
    {key:"GDP", value:"$76.52 billion (2019)"},
    {key:"Currency", value:"Zambian kwacha (ZMW)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+260"},
    {key:"ISO 3166 code", value:"ZM"},
    {key:"Internal TLD", value:".zm"}
   ];
});

africaDataApp.controller('zimbabwe-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Zimbabwe"},
    {key:"Size", value:"390,757 km2"},
    {key:"Population", value:"14.43 million (2018)"},
    {key:"Capital", value:"Harare"},
    {key:"Official Language(s)", value:"Chewa, Chibarwe, English, Kalanga"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"Emmerson Mnangagwa"},
    {key:"Vice-presidents", value:"Constantino Chiwenga, Kembo Mohadi"},
    {key:"GDP", value:"$22.290 billion (2019)"},
    {key:"Currency", value:"Zambian kwacha (ZMW)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+263"},
    {key:"ISO 3166 code", value:"ZW"},
    {key:"Internal TLD", value:".zw"}
   ];
});
