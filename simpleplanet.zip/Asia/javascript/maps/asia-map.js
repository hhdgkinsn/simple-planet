// Themes
am4core.useTheme(am4themes_animated);

// Create map instance
var chart = am4core.create("map", am4maps.MapChart);

// Set map definition
chart.geodata = am4geodata_worldUltra;


// Set projection
chart.projection = new am4maps.projections.Miller();

// Zoom control
chart.zoomControl = new am4maps.ZoomControl();

// Reset Map
var homeButton = new am4core.Button();
homeButton.events.on("hit", function(){
  chart.goHome();
});

homeButton.icon = new am4core.Sprite();
homeButton.padding(7, 5, 7, 5);
homeButton.width = 30;
homeButton.icon.path = "M16,8 L14,8 L14,16 L10,16 L10,10 L6,10 L6,16 L2,16 L2,8 L0,8 L8,0 L16,8 Z M16,8";
homeButton.marginBottom = 10;
homeButton.parent = chart.zoomControl;
homeButton.insertBefore(chart.zoomControl.plusButton);

// Zoom level
chart.homeZoomLevel = 2.2;
chart.homeGeoPoint = { longitude: 100, latitude: 50 };


// Asia
var groupData = [
	{"data": [{"id": "AF", "url": "/asia/countries/afghanistan.html"}] },
	{"data": [{"id": "AM", "url": "/asia/countries/armenia.html"}] },
	{"data": [{"id": "AZ", "url": "/asia/countries/azerbaijan.html"}] },
	{"data": [{"id": "BH", "url": "/asia/countries/bahrain.html"}] },
	{"data": [{"id": "BD", "url": "/asia/countries/bangladesh.html"}] },
	{"data": [{"id": "BT", "url": "/asia/countries/bhutan.html"}] },
	{"data": [{"id": "BN", "url": "/asia/countries/brunei.html"}] },
	{"data": [{"id": "KH", "url": "/asia/countries/cambodia.html"}] },
	{"data": [{"id": "CN", "url": "/asia/countries/china.html"}] },
	{"data": [{"id": "GE", "url": "/asia/countries/georgia.html"}] },
	{"data": [{"id": "HK"}] },
	{"data": [{"id": "IN", "url": "/asia/countries/india.html"}] },
	{"data": [{"id": "ID", "url": "/asia/countries/indonesia.html"}] },
	{"data": [{"id": "IR", "url": "/asia/countries/iran.html"}] },
	{"data": [{"id": "IL", "url": "/asia/countries/israel.html"}] },
	{"data": [{"id": "JP", "url": "/asia/countries/japan.html"}] },
	{"data": [{"id": "JO", "url": "/asia/countries/jordan.html"}] },
	{"data": [{"id": "KZ", "url": "/asia/countries/kazakhstan.html"}] },
	{"data": [{"id": "KW", "url": "/asia/countries/kuwait.html"}] },
	{"data": [{"id": "KG", "url": "/asia/countries/kyrgyzstan.html"}] },
	{"data": [{"id": "LA", "url": "/asia/countries/laos.html"}] },
	{"data": [{"id": "LB", "url": "/asia/countries/lebanon.html"}] },
	{"data": [{"id": "MO"}] },
	{"data": [{"id": "MY", "url": "/asia/countries/malaysia.html"}] },
	{"data": [{"id": "MV", "url": "/asia/countries/maldives.html"}] },
	{"data": [{"id": "MN", "url": "/asia/countries/mongolia.html"}] },
	{"data": [{"id": "MM", "url": "/asia/countries/myanmar.html"}] },
	{"data": [{"id": "NP", "url": "/asia/countries/nepal.html"}] },
	{"data": [{"id": "KP", "url": "/asia/countries/northkorea.html"}] },
	{"data": [{"id": "OM", "url": "/asia/countries/oman.html"}] },
	{"data": [{"id": "PK", "url": "/asia/countries/pakistan.html"}] },
	{"data": [{"id": "PH", "url": "/asia/countries/philippines.html"}] },
	{"data": [{"id": "QA", "url": "/asia/countries/qatar.html"}] },
	{"data": [{"id": "SA", "url": "/asia/countries/saudiarabia.html"}] },
	{"data": [{"id": "SG", "url": "/asia/countries/singapore.html"}] },
	{"data": [{"id": "KR", "url": "/asia/countries/southkorea.html"}] },
	{"data": [{"id": "LK", "url": "/asia/countries/srilanka.html"}] },
	{"data": [{"id": "SY", "url": "/asia/countries/syria.html"}] },
	{"data": [{"id": "TW", "url": "/asia/countries/taiwan.html"}] },
	{"data": [{"id": "TJ", "url": "/asia/countries/takikistam.html"}] },
	{"data": [{"id": "TH", "url": "/asia/countries/thailand.html"}] },
	{"data": [{"id": "TM", "url": "/asia/countries/turkmenistan.html"}] },
	{"data": [{"id": "AE", "url": "/asia/countries/uae.html"}] },
	{"data": [{"id": "UZ", "url": "/asia/countries/uzbekistan.html"}] },
	{"data": [{"id": "VN", "url": "/asia/countries/vietnam.html"}] },
	{"data": [{"id": "YE", "url": "/asia/countries/yemen.html"}] },
	{"data": [{"id": "RU", "url": "/asia/countries/russia.html"}] },
	{"data": [{"id": "IQ", "url": "/asia/countries/iraq.html"}] }
	];


var excludedCountries = ["AQ"];


groupData.forEach(function(group) {
  var series = chart.series.push(new am4maps.MapPolygonSeries());
  series.name = group.name;
  series.useGeodata = true;
  var includedCountries = [];
  group.data.forEach(function(country){
    includedCountries.push(country.id);
    excludedCountries.push(country.id);
  });
  series.include = includedCountries;

  series.fill = am4core.color("#c3d6a9");


  series.setStateOnChildren = true;
  var seriesHoverState = series.states.create("hover");


  var mapPolygonTemplate = series.mapPolygons.template;
  mapPolygonTemplate.fill = am4core.color("#a1d47f");
  mapPolygonTemplate.fillOpacity = 1;
  mapPolygonTemplate.nonScalingStroke = false;
  mapPolygonTemplate.stroke = am4core.color("#000");
  mapPolygonTemplate.strokeWidth = 0.2;
  mapPolygonTemplate.strokeOpacity = 0.5;
  mapPolygonTemplate.tooltipText = "{name}";
  mapPolygonTemplate.propertyFields.url = "url";

  var hoverState = mapPolygonTemplate.states.create("hover");
  hoverState.properties.fill = am4core.color("#8ec16c");


  series.data = JSON.parse(JSON.stringify(group.data));
});


// The rest of the world.
var worldSeries = chart.series.push(new am4maps.MapPolygonSeries());
var worldSeriesName = "world";
worldSeries.name = worldSeriesName;
worldSeries.useGeodata = true;
worldSeries.exclude = excludedCountries;
worldSeries.fillOpacity = 1;
worldSeries.mapPolygons.template.nonScalingStroke = true;

worldSeries.mapPolygons.template.stroke = worldSeries.mapPolygons.template.fill;
worldSeries.mapPolygons.template.strokeWidth = 0;
