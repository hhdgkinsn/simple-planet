var asiaDataApp = angular.module('asiaDataApp', []);

asiaDataApp.controller('asia-info', function($scope) {
  $scope.info = [
    {key:"Size", value:"44.58 million km²"},
    {key:"Population", value:"4.6 bil"},
    {key:"Number of countries", value:"48"},
    {key:"Largest Country", value:"Russia"},
    {key:"Smallest Country", value:"Maldives"},
    {key:"Most populated country", value:"China"},
    {key:"Most Populated City", value:"Tokyo, Japan"},
    {key:"Highest Point", value:"Mount Everest, Nepal"}
   ];
});

asiaDataApp.controller('afghanistan-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Islamic Republic of Afghanistan"},
    {key:"Size", value:"652,230 km2"},
    {key:"Population", value:"32.22 million (2019)"},
    {key:"Capital", value:"Kabul"},
    {key:"Official Language(s)", value:"Pashto, Dari"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"	Ashraf Ghani"},
    {key:"Vice president", value:"Abdul Rashid Dostum"},
    {key:"GDP", value:"$21.657 billion (2019)"},
    {key:"Currency", value:"Afghani (AFN)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+93"},
    {key:"ISO 3166 code", value:"AF"},
    {key:"Internal TLD", value:".af"}
   ];
});

asiaDataApp.controller('armenia-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Armenia"},
    {key:"Size", value:"29,743 km2"},
    {key:"Population", value:"2.95 million (2018)"},
    {key:"Capital", value:"Yerevan"},
    {key:"Official Language(s)", value:"Armenian"},
    {key:"Government", value:"Parlimentary"},
    {key:"President", value:"Armen Sarkissian"},
    {key:"Vice president", value:"Nikol Pashinyan"},
    {key:"GDP", value:"$32.893 billion (2019)"},
    {key:"Currency", value:"Dram (AMD)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+374"},
    {key:"ISO 3166 code", value:"AM"},
    {key:"Internal TLD", value:".am"}
   ];
});

asiaDataApp.controller('azerbaijan-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Azerbaijan"},
    {key:"Size", value:"86,600 km2"},
    {key:"Population", value:"10 million (2019)"},
    {key:"Capital", value:"Baku"},
    {key:"Official Language(s)", value:"Azerbaijani"},
    {key:"Government", value:"Semi-presidential"},
    {key:"President", value:"	Ilham Aliyev"},
    {key:"Vice president", value:"Mehriban Aliyeva"},
    {key:"Prime minister", value:"Ali Asadov"},
    {key:"GDP", value:"$189.050 billion (2019)"},
    {key:"Currency", value:"Manat (AZN)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+994"},
    {key:"ISO 3166 code", value:"AZ"},
    {key:"Internal TLD", value:".az"}
   ];
});

asiaDataApp.controller('bahrain-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Kingdom of Bahrain"},
    {key:"Size", value:"780 km2"},
    {key:"Population", value:"1.56 million (2018)"},
    {key:"Capital", value:"Manama"},
    {key:"Official Language(s)", value:"Arabic"},
    {key:"Government", value:"Parlimentary, Monarchy"},
    {key:"Monarch", value:"Hamad bin Isa Al Khalifa"},
    {key:"Prime minister", value:"Khalifa bin Salman Al Khalifa"},
    {key:"GDP", value:"$78.760 billion (2019)"},
    {key:"Currency", value:"Bahraini dinar (BHD)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+973"},
    {key:"ISO 3166 code", value:"BH"},
    {key:"Internal TLD", value:".bh"}
   ];
});

asiaDataApp.controller('bangladesh-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"People's Republic of Bangladesh"},
    {key:"Size", value:"	147,570 km2"},
    {key:"Population", value:"161.37 million (2018)"},
    {key:"Capital", value:"Dhaka"},
    {key:"Official Language(s)", value:"Bengali"},
    {key:"Government", value:"Parlimentary"},
    {key:"President", value:"	Abdul Hamid"},
    {key:"Prime minister", value:"	Sheikh Hasina"},
    {key:"GDP", value:"$917.805 billion (2020)"},
    {key:"Currency", value:"Bangladeshi taka (BDT)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+880"},
    {key:"ISO 3166 code", value:"BD"},
    {key:"Internal TLD", value:".bd"}
   ];
});

asiaDataApp.controller('bhutan-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Kingdom of Bhutan"},
    {key:"Size", value:"38,394 km2"},
    {key:"Population", value:"741,700 (2019)"},
    {key:"Capital", value:"Thimphu"},
    {key:"Official Language(s)", value:"Dzongkha"},
    {key:"Government", value:"Parlimentary, Monarchy"},
    {key:"Monarch", value:"Jigme Khesar Namgyel Wangchuck"},
    {key:"Prime minister", value:"Lotay Tshering"},
    {key:"GDP", value:"$7.701 billion (2018)"},
    {key:"Currency", value:"	Ngultrum (BTN)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+975"},
    {key:"ISO 3166 code", value:"BT"},
    {key:"Internal TLD", value:".bt"}
   ];
});

asiaDataApp.controller('brunei-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Nation of Brunei, the Abode of Peace"},
    {key:"Size", value:"38,394 km2"},
    {key:"Population", value:"741,700 (2019)"},
    {key:"Capital", value:"Bandar Seri Begawan"},
    {key:"Official Language(s)", value:"Malay"},
    {key:"Government", value:"Islamic absolute monarchy"},
    {key:"Sultan, Yang di-Pertuan, Prime Minister", value:"Hassanal Bolkiah"},
    {key:"GDP", value:"$36.854 billion (2019)"},
    {key:"Currency", value:"Brunei dollar (BND)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+673"},
    {key:"ISO 3166 code", value:"BN"},
    {key:"Internal TLD", value:".bn"}
   ];
});

asiaDataApp.controller('cambodia-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Kingdom of Cambodia"},
    {key:"Size", value:"181,035 km2"},
    {key:"Population", value:"15.28 million (2019)"},
    {key:"Capital", value:"Phnom Penh"},
    {key:"Official Language(s)", value:"Khmer"},
    {key:"Government", value:"Parlimentary, Monarchy, Dictatorship"},
    {key:"King", value:"Norodom Sihamoni"},
    {key:"Prime minister", value:"Hun Sen"},
    {key:"GDP", value:"	$76.635 billion (2019)"},
    {key:"Currency", value:"Riel (KHR)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+855"},
    {key:"ISO 3166 code", value:"KH"},
    {key:"Internal TLD", value:".kn"}
   ];
});

asiaDataApp.controller('china-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"People's Republic of China"},
    {key:"Size", value:"9,596,961 km2"},
    {key:"Population", value:"1.42 billion (2018)"},
    {key:"Capital", value:"Beijing"},
    {key:"Official Language(s)", value:"Mandarin"},
    {key:"Government", value:"Marxist-Leninist, Socialist"},
    {key:"President", value:"Xi Jinping"},
    {key:"GDP", value:"$27.309 trillion (2019)"},
    {key:"Currency", value:"Renminbi (CNY)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+86"},
    {key:"ISO 3166 code", value:"CN"},
    {key:"Internal TLD", value:".cn"}
   ];
});

asiaDataApp.controller('christmasisland-info', function($scope) {
  $scope.info = [
    {key:"Sovereign state", value:"Australia"},
    {key:"Size", value:"135 km2"},
    {key:"Population", value:"1,843 (2016)"},
    {key:"Capital", value:"Flying Fish Cove"},
    {key:"Government", value:"Dependency"},
    {key:"Monarch", value:"Elizabeth II"},
    {key:"Governor-General", value:"David Hurley"},
    {key:"Currency", value:"Australian dollar (AUD)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+61 891"},
    {key:"ISO 3166 code", value:"CX"},
    {key:"Internal TLD", value:".cx"}
   ];
});

asiaDataApp.controller('cocoskeelingislands-info', function($scope) {
  $scope.info = [
    {key:"Sovereign state", value:"Australia"},
    {key:"Size", value:"14 km2"},
    {key:"Population", value:"544 (2016)"},
    {key:"Capital", value:"West Island"},
    {key:"Government", value:"Dependency"},
    {key:"Monarch", value:"Elizabeth II"},
    {key:"Governor-General", value:"David Hurley"},
    {key:"Currency", value:"Australian dollar (AUD)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+61 891"},
    {key:"ISO 3166 code", value:"CC"},
    {key:"Internal TLD", value:".cc"}
   ];
});

asiaDataApp.controller('palestine-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"State of Palestine"},
    {key:"Size", value:"6,020 km2"},
    {key:"Population", value:"5.05 million (2020)"},
    {key:"Official Language(s)", value:"Arabic"},
    {key:"Government", value:"Semi-presidential"},
    {key:"President", value:"Mahmoud Abbas"},
    {key:"Prime minister", value:"Mohammad Shtayyeh"},
    {key:"GDP", value:"$11.95 billion (2008)"},
    {key:"Currency", value:"Egyptian pound (EGP), Israeli new shekel (ILS), Jordanian dinar (JOD)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+970"},
    {key:"ISO 3166 code", value:"PS"},
    {key:"Internal TLD", value:".ps"}
   ];
});

asiaDataApp.controller('georgia-info', function($scope) {
  $scope.info = [
    {key:"Size", value:"69,700 km2"},
    {key:"Population", value:"3.72 million (2019)"},
    {key:"Capital", value:"Tbilisi"},
    {key:"Official Language(s)", value:"Georgian, Abkhazian"},
    {key:"Government", value:"Parlimentary"},
    {key:"President", value:"	Salome Zurabishvili"},
    {key:"Prime minister", value:"Giorgi Gakharia"},
    {key:"GDP", value:"$46.05 billion (2019)"},
    {key:"Currency", value:"Georgian lari (GEL)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+995"},
    {key:"ISO 3166 code", value:"GE"},
    {key:"Internal TLD", value:".ge"}
   ];
});

asiaDataApp.controller('india-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of India"},
    {key:"Size", value:"3,287,263 km2"},
    {key:"Population", value:"1.2 billion (2018)"},
    {key:"Capital", value:"New Dheli"},
    {key:"Official Language(s)", value:"Hindi, English"},
    {key:"Government", value:"Parlimentary"},
    {key:"President", value:"Ram Nath Kovind"},
    {key:"Vice-president", value:"Venkaiah Naidu"},
    {key:"Prime minister", value:"Narendra Modi"},
    {key:"GDP", value:"$11.326 trillion (2019)"},
    {key:"Currency", value:"Indian rupee (INR)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+91"},
    {key:"ISO 3166 code", value:"IN"},
    {key:"Internal TLD", value:".in"}
   ];
});

asiaDataApp.controller('indonesia-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Indonesia"},
    {key:"Size", value:"1,904,569 km2"},
    {key:"Population", value:"267.67 million (2018)"},
    {key:"Capital", value:"Jakarta"},
    {key:"Official Language(s)", value:"Indonesian"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"	Joko Widodo"},
    {key:"Vice-president", value:"	Ma'ruf Amin"},
    {key:"GDP", value:"$3.740 trillion (2019)"},
    {key:"Currency", value:"Indonesian rupiah (IDR)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+62"},
    {key:"ISO 3166 code", value:"ID"},
    {key:"Internal TLD", value:".id"}
   ];
});

asiaDataApp.controller('iran-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Islamic Republic of Iran"},
    {key:"Size", value:"1,648,195 km2"},
    {key:"Population", value:"83.81 million (2019)"},
    {key:"Capital", value:"Tehran"},
    {key:"Official Language(s)", value:"Persian"},
    {key:"Government", value:"Presidential"},
    {key:"Supreme leader", value:"Ali Khamenei"},
    {key:"President", value:"Hassan Rouhani"},
    {key:"Vice-president", value:"Eshaq Jahangiri"},
    {key:"GDP", value:"$1.471 trillion (2019)"},
    {key:"Currency", value:"Rial (IRR)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+98"},
    {key:"ISO 3166 code", value:"IR"},
    {key:"Internal TLD", value:".ir"}
   ];
});

asiaDataApp.controller('iraq-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Iraq"},
    {key:"Size", value:"437,072 km2"},
    {key:"Population", value:"38.43 million (2018)"},
    {key:"Capital", value:"Baghdad"},
    {key:"Official Language(s)", value:"Arabic, Kurdish"},
    {key:"Government", value:"Parlimentary"},
    {key:"President", value:"	Barham Salih"},
    {key:"Prime minister", value:"Mohammed Tawfiq Allawi"},
    {key:"GDP", value:"$733.926 billion (2019)"},
    {key:"Currency", value:"Iraqi dinar (IQD)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+964"},
    {key:"ISO 3166 code", value:"IQ"},
    {key:"Internal TLD", value:".iq"}
   ];
});

asiaDataApp.controller('israel-info', function($scope) {
  $scope.info = [
    {key:"Size", value:"22,072 km2"},
    {key:"Population", value:"9.15 million (2020)"},
    {key:"Capital", value:"Jerusalem"},
    {key:"Official Language(s)", value:"Hebrew"},
    {key:"Government", value:"Parlimentary"},
    {key:"President", value:"Reuven Rivlin"},
    {key:"Prime minister", value:"Benjamin Netanyahu"},
    {key:"GDP", value:"$353.645 billion (2019)"},
    {key:"Currency", value:"New shekel (ILS)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+972"},
    {key:"ISO 3166 code", value:"IL"},
    {key:"Internal TLD", value:".il"}
   ];
});

asiaDataApp.controller('japan-info', function($scope) {
  $scope.info = [
    {key:"Size", value:"377,975 km2"},
    {key:"Population", value:"126.15 million (2020)"},
    {key:"Capital", value:"Tokyo"},
    {key:"Official Language(s)", value:"Japanese"},
    {key:"Government", value:"Parlimentary"},
    {key:"Emperor", value:"Naruhito"},
    {key:"Prime minister", value:"Shinzō Abe"},
    {key:"GDP", value:"$5.888 trillion (2020)"},
    {key:"Currency", value:"Japanese yen (JPY)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+81"},
    {key:"ISO 3166 code", value:"JP"},
    {key:"Internal TLD", value:".jp"}
   ];
});

asiaDataApp.controller('jordan-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Hashemite Kingdom of Jordan"},
    {key:"Size", value:"89,342 km2"},
    {key:"Population", value:"10.4 million (2019)"},
    {key:"Capital", value:"Amman"},
    {key:"Official Language(s)", value:"Arabic"},
    {key:"Government", value:"Parlimentary, Monarchy"},
    {key:"Monarch", value:"	Abdullah II"},
    {key:"Prime minister", value:"Omar Razzaz"},
    {key:"GDP", value:"$93.159 billion (2020)"},
    {key:"Currency", value:"Jordanian dinar (JOD)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+962"},
    {key:"ISO 3166 code", value:"JO"},
    {key:"Internal TLD", value:".jo"}
   ];
});

asiaDataApp.controller('kazakhstan-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Kazakhstan"},
    {key:"Size", value:"2,724,900 km2"},
    {key:"Population", value:"18.44 million (2019)"},
    {key:"Capital", value:"Nur-Sultan"},
    {key:"Official Language(s)", value:"Kazakh, Russian"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"Kassym-Jomart Tokayev"},
    {key:"Prime minister", value:"Askar Mamin"},
    {key:"GDP", value:"$569.813 billion (2020)"},
    {key:"Currency", value:"Tenge (KZT)"},
    {key:"Driving side", value:"Right"},
    {key:"ISO 3166 code", value:"KZ"},
    {key:"Internal TLD", value:".kz"}
   ];
});

asiaDataApp.controller('kuwait-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"State of Kuwait"},
    {key:"Size", value:"17,818 km2"},
    {key:"Population", value:"4.62 million (2018)"},
    {key:"Capital", value:"Kuwait City"},
    {key:"Official Language(s)", value:"Arabic"},
    {key:"Government", value:"Monarchy"},
    {key:"Emir, Prime minister", value:"Sabah Ahmad al-Sabah"},
    {key:"GDP", value:"$303 billion (2018)"},
    {key:"Currency", value:"Kuwaiti dinar (KWD)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+965"},
    {key:"ISO 3166 code", value:"KW"},
    {key:"Internal TLD", value:".kw"}
   ];
});

asiaDataApp.controller('kyrgyzstan-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Kyrgyz Republic"},
    {key:"Size", value:"199,951 km2"},
    {key:"Population", value:"6.38 million (2019)"},
    {key:"Capital", value:"Bishkek"},
    {key:"Official Language(s)", value:"Kyrgyz, Russian"},
    {key:"Government", value:"Parlimentary"},
    {key:"President", value:"	Sooronbay Jeenbekov"},
    {key:"Prime minister", value:"Muhammetkaliy Abulgaziyev"},
    {key:"GDP", value:"$25.915 billion (2019)"},
    {key:"Currency", value:"	Som (KGS)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+996"},
    {key:"ISO 3166 code", value:"KG"},
    {key:"Internal TLD", value:".kg"}
   ];
});

asiaDataApp.controller('laos-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Lao People's Democratic Republic"},
    {key:"Size", value:"237,955 km2"},
    {key:"Population", value:"7 million (2015)"},
    {key:"Capital", value:"Vientiane"},
    {key:"Official Language(s)", value:"Lao"},
    {key:"Government", value:"Marxist-Leninist, Socialist"},
    {key:"President", value:"Bounnhang Vorachith"},
    {key:"Vice-president", value:"Phankham Viphavanh"},
    {key:"Prime minister", value:"Thongloun Sisoulith"},
    {key:"GDP", value:"$58.329 billion (2019)"},
    {key:"Currency", value:"Kip (LAK)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+856"},
    {key:"ISO 3166 code", value:"LA"},
    {key:"Internal TLD", value:".la"}
   ];
});

asiaDataApp.controller('lebanon-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Lebanese Republic"},
    {key:"Size", value:"10,452 km2"},
    {key:"Population", value:"6.85 million (2018)"},
    {key:"Capital", value:"Beirut"},
    {key:"Official Language(s)", value:"Arabic"},
    {key:"Government", value:"Parlimentary"},
    {key:"President", value:"Michel Aoun"},
    {key:"Prime minister", value:"Hassan Diab"},
    {key:"GDP", value:"	$58 billion (2019)"},
    {key:"Currency", value:"Lebanese pound (LBP)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+961"},
    {key:"ISO 3166 code", value:"LB"},
    {key:"Internal TLD", value:".lb"}
   ];
});

asiaDataApp.controller('malaysia-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Federation of Malaysia"},
    {key:"Size", value:"330,803 km2"},
    {key:"Population", value:"32.77 million (2019)"},
    {key:"Capital", value:"Kuala Lumpur"},
    {key:"Official Language(s)", value:"Malay"},
    {key:"Government", value:"Parlimentary, Monarchy"},
    {key:"Monarch", value:"Abdullah al-Haj"},
    {key:"Prime minister", value:"Mahathir Mohamad"},
    {key:"GDP", value:"$1.148 trillion (2019)"},
    {key:"Currency", value:"Ringgit (MYR)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+60"},
    {key:"ISO 3166 code", value:"MY"},
    {key:"Internal TLD", value:".my"}
   ];
});

asiaDataApp.controller('maldives-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Maldives"},
    {key:"Size", value:"298 km2"},
    {key:"Population", value:"392,473 (2018)"},
    {key:"Capital", value:"Malé"},
    {key:"Official Language(s)", value:"Dhivehi"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"Ibrahim Mohamed Solih"},
    {key:"Vice president", value:"Faisal Naseem"},
    {key:"GDP", value:"$8.608 billion (2019)"},
    {key:"Currency", value:"Maldivian rufiyaa (MVR)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+960"},
    {key:"ISO 3166 code", value:"MV"},
    {key:"Internal TLD", value:".mv"}
   ];
});

asiaDataApp.controller('mongolia-info', function($scope) {
  $scope.info = [
    {key:"Size", value:"1,566,000 km2"},
    {key:"Population", value:"3.27 million (2020)"},
    {key:"Capital", value:"Ulaanbaatar"},
    {key:"Official Language(s)", value:"Mongolian"},
    {key:"Government", value:"Semi-presidential"},
    {key:"President", value:"Khaltmaagiin Battulga"},
    {key:"Prime minister", value:"Ukhnaagiin Khürelsükh"},
    {key:"GDP", value:"	$47 billion (2019)"},
    {key:"Currency", value:"Tögrög (MNT)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+976"},
    {key:"ISO 3166 code", value:"MN"},
    {key:"Internal TLD", value:".mn"}
   ];
});

asiaDataApp.controller('myanmar-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of the Union of Myanmar"},
    {key:"Size", value:"676,578 km2"},
    {key:"Population", value:"53.58 million (2017)"},
    {key:"Capital", value:"Naypyidaw"},
    {key:"Official Language(s)", value:"Burmese"},
    {key:"Government", value:"Parlimentary"},
    {key:"President", value:"Win Myint"},
    {key:"Vice president", value:"Myint Swe"},
    {key:"GDP", value:"$355 billion (2019)"},
    {key:"Currency", value:"Kyat (MMK)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+95"},
    {key:"ISO 3166 code", value:"MM"},
    {key:"Internal TLD", value:".mm"}
   ];
});

asiaDataApp.controller('nepal-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Federal Democratic Republic of Nepal"},
    {key:"Size", value:"147,181 km2 "},
    {key:"Population", value:"28 million (2018)"},
    {key:"Capital", value:"Kathmandu"},
    {key:"Official Language(s)", value:"Nepali"},
    {key:"Government", value:"Parlimentary"},
    {key:"President", value:"Bidhya Devi Bhandari"},
    {key:"Vice president", value:"Nanda Kishor Pun"},
    {key:"Prime minister", value:"Khadga Prasad Sharma Oli"},
    {key:"GDP", value:"	$84 billion (2018)"},
    {key:"Currency", value:"Nepalese rupee (NPR)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+977"},
    {key:"ISO 3166 code", value:"NP"},
    {key:"Internal TLD", value:".np"}
   ];
});

asiaDataApp.controller('northkorea-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Democratic People's Republic of Korea"},
    {key:"Size", value:"120,540 km2"},
    {key:"Population", value:"25.54 million (2018)"},
    {key:"Capital", value:"Pyongyang"},
    {key:"Official Language(s)", value:"Korean"},
    {key:"Government", value:"One-party"},
    {key:"Party and State Affairs Commission Chairman", value:"Kim Jong-un"},
    {key:"President of Assembly Presidium", value:"Choe Ryong-hae"},
    {key:"Prime minister", value:"Khadga Prasad Sharma Oli"},
    {key:"GDP", value:"$40 billion (2014)"},
    {key:"Currency", value:"Korean People's won (KPW)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+850"},
    {key:"ISO 3166 code", value:"KP"},
    {key:"Internal TLD", value:".kp"}
   ];
});

asiaDataApp.controller('oman-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Sultanate of Oman"},
    {key:"Size", value:"309,500 km2"},
    {key:"Population", value:"4.8 million (2018)"},
    {key:"Capital", value:"Muscat"},
    {key:"Official Language(s)", value:"Arabic"},
    {key:"Government", value:"Parlimentary"},
    {key:"Sultan, Prime minister", value:"	Haitham bin Tariq Al Said"},
    {key:"GDP", value:"$203.959 billion (2018)"},
    {key:"Currency", value:"Rial (OMR)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+968"},
    {key:"ISO 3166 code", value:"OM"},
    {key:"Internal TLD", value:".om"}
   ];
});

asiaDataApp.controller('pakistan-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Islamic Republic of Pakistan"},
    {key:"Size", value:"881,913 km2"},
    {key:"Population", value:"212.2 million (2018)"},
    {key:"Capital", value:"Islamabad"},
    {key:"Official Language(s)", value:"English, Urdu"},
    {key:"Government", value:"Parlimentary"},
    {key:"President", value:"Arif Alvi"},
    {key:"Prime minister", value:"Imran Khan"},
    {key:"GDP", value:"$1.202 trillion (2019)"},
    {key:"Currency", value:"Pakistani (PKR)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+92"},
    {key:"ISO 3166 code", value:"PK"},
    {key:"Internal TLD", value:".pk"}
   ];
});

asiaDataApp.controller('philippines-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of the Philippines"},
    {key:"Size", value:"300,000 km2"},
    {key:"Population", value:"100.98 million (2015)"},
    {key:"Capital", value:"Manila"},
    {key:"Official Language(s)", value:"Filipino, English"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"Rodrigo Duterte"},
    {key:"Vice-president", value:"Maria Leonor Robredo"},
    {key:"GDP", value:"$1.110 trillion (2020)"},
    {key:"Currency", value:"Peso (PHP)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+63"},
    {key:"ISO 3166 code", value:"PH"},
    {key:"Internal TLD", value:".ph"}
   ];
});

asiaDataApp.controller('qatar-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"State of Qatar"},
    {key:"Size", value:"2,641,669"},
    {key:"Population", value:"1.69 million (2010)"},
    {key:"Capital", value:"Doha"},
    {key:"Official Language(s)", value:"Arabic"},
    {key:"Government", value:"Monarchy"},
    {key:"Monarch", value:"	Tamim bin Hamad"},
    {key:"Prime minister", value:"Khalid Bin Khalifa"},
    {key:"GDP", value:"	$357.338 billion (2018)"},
    {key:"Currency", value:"Riyal (QAR)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+974"},
    {key:"ISO 3166 code", value:"QA"},
    {key:"Internal TLD", value:".qa"}
   ];
});

asiaDataApp.controller('russia-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Russian Federation"},
    {key:"Size", value:"17,098,246 km2"},
    {key:"Population", value:"146.74 million (2020)"},
    {key:"Capital", value:"Moscow"},
    {key:"Official Language(s)", value:"Russian"},
    {key:"Government", value:"Semi-presidential"},
    {key:"President", value:"Vladimir Putin"},
    {key:"Prime minister", value:"Mikhail Mishustin"},
    {key:"GDP", value:"$4,519 trillion (2020)"},
    {key:"Currency", value:"Russian ruble(RUB)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+7"},
    {key:"ISO 3166 code", value:"RU"},
    {key:"Internal TLD", value:".ru"}
   ];
});

asiaDataApp.controller('saudiarabia-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Kingdom of Saudi Arabia"},
    {key:"Size", value:"2,149,690 km2"},
    {key:"Population", value:"146.74 million (2020)"},
    {key:"Capital", value:"Riyadh"},
    {key:"Official Language(s)", value:"Arabic"},
    {key:"Government", value:"Monarchy"},
    {key:"King", value:"Salman"},
    {key:"Crown Prince", value:"Mohammad bin Salman"},
    {key:"GDP", value:"$1.924 trillion (2019)"},
    {key:"Currency", value:"Saudi riyal (SAR))"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+966"},
    {key:"ISO 3166 code", value:"SA"},
    {key:"Internal TLD", value:".sa"}
   ];
});

asiaDataApp.controller('singapore-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Singapore"},
    {key:"Size", value:"725.1 km2"},
    {key:"Population", value:"5.63 million (2018)"},
    {key:"Capital", value:"Singapore"},
    {key:"Official Language(s)", value:"English, Malay, Mandarin, Tamil"},
    {key:"Government", value:"Parlimentary"},
    {key:"President", value:"	Halimah Yacob"},
    {key:"Prime minister", value:"Lee Hsien Loong"},
    {key:"GDP", value:"$589.187 billion (2019)"},
    {key:"Currency", value:"Singapore dollar (SGD)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+65"},
    {key:"ISO 3166 code", value:"SG"},
    {key:"Internal TLD", value:".sg"}
   ];
});

asiaDataApp.controller('southkorea-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Korea"},
    {key:"Size", value:"100,363 km2"},
    {key:"Population", value:"5.63 million (2018)"},
    {key:"Capital", value:"Seoul"},
    {key:"Official Language(s)", value:"Korean"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"Moon Jae-in"},
    {key:"Prime minister", value:"Chung Sye-kyun"},
    {key:"GDP", value:"$2.418 trillion (2020)"},
    {key:"Currency", value:"Korean Republic won (KRW)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+82"},
    {key:"ISO 3166 code", value:"KR"},
    {key:"Internal TLD", value:".kr"}
   ];
});

asiaDataApp.controller('srilanka-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Democratic Socialist Republic of Sri Lanka"},
    {key:"Size", value:"65,610 km2"},
    {key:"Population", value:"21.67 million (2018)"},
    {key:"Capital", value:"	Sri Jayawardenepura Kotte"},
    {key:"Official Language(s)", value:"Sinhala, Tamil, English"},
    {key:"Government", value:"Semi-presidential"},
    {key:"President", value:"Gotabaya Rajapaksa"},
    {key:"Prime minister", value:"Mahinda Rajapaksa"},
    {key:"GDP", value:"$304.826 billion (2019)"},
    {key:"Currency", value:"Sri Lankan rupee (LKR)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+94"},
    {key:"ISO 3166 code", value:"LK"},
    {key:"Internal TLD", value:".lk"}
   ];
});

asiaDataApp.controller('syria-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Syrian Arab Republic"},
    {key:"Size", value:"185,180 km2"},
    {key:"Population", value:"17 million (2019)"},
    {key:"Capital", value:"Damascus"},
    {key:"Official Language(s)", value:"Arabic"},
    {key:"Government", value:"Semi-presidential"},
    {key:"President", value:"Bashar al-Assad"},
    {key:"Prime minister", value:"Imad Khamis"},
    {key:"GDP", value:"$50.28 billion (2015)"},
    {key:"Currency", value:"Syrian pound (SYP)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+963"},
    {key:"ISO 3166 code", value:"SY"},
    {key:"Internal TLD", value:".sy"}
   ];
});

asiaDataApp.controller('tajikistan-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Tajikistan"},
    {key:"Size", value:"143,100 km2"},
    {key:"Population", value:"2.27 million (2019)"},
    {key:"Capital", value:"Dushanbe"},
    {key:"Official Language(s)", value:"Tajik, Russian"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"	Emomali Rahmon"},
    {key:"Prime minister", value:"Kokhir Rasulzoda"},
    {key:"GDP", value:"$30.547 billion (2018)"},
    {key:"Currency", value:"Somoni (TJS)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+992"},
    {key:"ISO 3166 code", value:"TJ"},
    {key:"Internal TLD", value:".tj"}
   ];
});

asiaDataApp.controller('thailand-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Kingdom of Thailand"},
    {key:"Size", value:"513,120 km2"},
    {key:"Population", value:"69.42 million (2018)"},
    {key:"Capital", value:"Bangkok"},
    {key:"Official Language(s)", value:"Thai"},
    {key:"Government", value:"Parlimentary"},
    {key:"Monarch", value:"Maha Vajiralongkorn"},
    {key:"Prime minister", value:"Prayut Chan-o-cha"},
    {key:"GDP", value:"$1.390 trillion (2019)"},
    {key:"Currency", value:"	Baht (THB)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+66"},
    {key:"ISO 3166 code", value:"TH"},
    {key:"Internal TLD", value:".th"}
   ];
});

asiaDataApp.controller('timorleste-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Democratic Republic of Timor-Leste"},
    {key:"Size", value:"15,007 km2"},
    {key:"Population", value:"1.18 million (2015)"},
    {key:"Capital", value:"Dili"},
    {key:"Official Language(s)", value:"Tetum, Portuguese"},
    {key:"Government", value:"Semi-presidential"},
    {key:"President", value:"	Francisco Guterres"},
    {key:"Prime minister", value:"Taur Matan Ruak"},
    {key:"GDP", value:"	$7.221 billion (2019)"},
    {key:"Currency", value:"United States dollar (USD)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+670"},
    {key:"ISO 3166 code", value:"TL"},
    {key:"Internal TLD", value:".tl"}
   ];
});

asiaDataApp.controller('turkmenistan-info', function($scope) {
  $scope.info = [
    {key:"Size", value:"491,210 km2"},
    {key:"Population", value:"5.85 million (2018)"},
    {key:"Capital", value:"Ashgabat"},
    {key:"Official Language(s)", value:"Turkmen"},
    {key:"Government", value:"Presidential, Dictatorship"},
    {key:"President", value:"Gurbanguly Berdimuhamedow"},
    {key:"Vice President", value:"Raşit Meredow"},
    {key:"GDP", value:"$42.764 billion (2018)"},
    {key:"Currency", value:"Turkmen new manat (TMT)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+993"},
    {key:"ISO 3166 code", value:"TM"},
    {key:"Internal TLD", value:".tm"}
   ];
});

asiaDataApp.controller('uae-info', function($scope) {
  $scope.info = [
    {key:"Size", value:"83,600 km2"},
    {key:"Population", value:"9.59 million (2018)"},
    {key:"Capital", value:"Abu Dhabi"},
    {key:"Official Language(s)", value:"Arabic"},
    {key:"Government", value:"Monarchy"},
    {key:"President", value:"Khalifa bin Zayed Al Nahyan"},
    {key:"Prime minister", value:"Mohammed bin Rashid Al Maktoum"},
    {key:"GDP", value:"$732.861 billion (2018)"},
    {key:"Currency", value:"UAE dirham (AED)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+971"},
    {key:"ISO 3166 code", value:"AE"},
    {key:"Internal TLD", value:".ae"}
   ];
});

asiaDataApp.controller('uzbekistan-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Uzbekistan"},
    {key:"Size", value:"448,978 km2"},
    {key:"Population", value:"33.9 million (2019)"},
    {key:"Capital", value:"Tashkent"},
    {key:"Official Language(s)", value:"Uzbek"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"Shavkat Mirziyoyev"},
    {key:"Prime minister", value:"Abdulla Aripov"},
    {key:"GDP", value:"$60.490 billion (2019)"},
    {key:"Currency", value:"Uzbek som (UZS)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+998"},
    {key:"ISO 3166 code", value:"UZ"},
    {key:"Internal TLD", value:".uz"}
   ];
});

asiaDataApp.controller('vietnam-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Socialist Republic of Vietnam"},
    {key:"Size", value:"331,212 km2"},
    {key:"Population", value:"95.54 million (2018)"},
    {key:"Capital", value:"Hanoi"},
    {key:"Official Language(s)", value:"	Vietnamese"},
    {key:"Government", value:"Marxist-Leninist, Socialist"},
    {key:"President", value:"Nguyễn Phú Trọng"},
    {key:"Prime minister", value:"Nguyễn Xuân Phúc"},
    {key:"GDP", value:"$770.227 billion (2019)"},
    {key:"Currency", value:"đồng (VND)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+84"},
    {key:"ISO 3166 code", value:"VN"},
    {key:"Internal TLD", value:".vn"}
   ];
});

asiaDataApp.controller('yemen-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Yemen"},
    {key:"Size", value:"527,968 km2"},
    {key:"Population", value:"28.49 million (2018)"},
    {key:"Capital", value:"Sana'a"},
    {key:"Official Language(s)", value:"Arabic"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"Abdrabbuh Mansur Hadi"},
    {key:"Vice president", value:"Abdrabbuh Mansur Hadi"},
    {key:"Prime minister", value:"Ali Mohsen al-Ahmar"},
    {key:"GDP", value:"$73.348 billion (2018)"},
    {key:"Currency", value:"Yemeni rial (YER)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+967"},
    {key:"ISO 3166 code", value:"YE"},
    {key:"Internal TLD", value:".ye"}
   ];
});
