var southamericaDataApp = angular.module('southamericaDataApp', []);

southamericaDataApp.controller('southamerica-info', function($scope) {
  $scope.info = [
    {key:"Size", value:"17.84 million km²"},
    {key:"Population", value:"423.5 mil (2018)"},
    {key:"Number of countries", value:"13"},
    {key:"Largest Country", value:"Brazil"},
    {key:"Smallest Country", value:"Suriname"},
    {key:"Most populated country", value:"Brazil"},
    {key:"Most Populated City", value:"Sao Paulo, Brazil"},
    {key:"Highest Point", value:"Aconcagua, Argentina"}
   ];
});

southamericaDataApp.controller('aruba-info', function($scope) {
  $scope.info = [
    {key:"Sovereign state", value:"Netherlands"},
    {key:"Size", value:"180 km2"},
    {key:"Population", value:"112,309 (2019)"},
    {key:"Capital", value:"Oranjestad"},
    {key:"Official Language(s)", value:"Dutch, Papiamento"},
    {key:"Government", value:"Parliamentary, Monarchy"},
    {key:"Monarch", value:"Willem-Alexander"},
    {key:"Governor", value:"Alfonso Boekhoudt"},
    {key:"Prime Minister", value:"Evelyn Wever-Croes"},
    {key:"GDP", value:"$4.483 billion (2018)"},
    {key:"Currency", value:"Aruban florin (AWG)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+297"},
    {key:"ISO 3166 code", value:"AW"},
    {key:"Internal TLD", value:".aw"}
   ];
});

southamericaDataApp.controller('bolivia-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Plurinational State of Bolivia"},
    {key:"Size", value:"1,098,581 km2"},
    {key:"Population", value:"11.42 million (2019)"},
    {key:"Capital", value:"Sucre"},
    {key:"Official Language(s)", value:"Spanish"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"Jeanine Áñez"},
    {key:"GDP", value:"$89.018 billion (2019)"},
    {key:"Currency", value:"Boliviano (BOB)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+591"},
    {key:"ISO 3166 code", value:"BO"},
    {key:"Internal TLD", value:".bo"}
   ];
});

southamericaDataApp.controller('brazil-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Federative Republic of Brazil"},
    {key:"Size", value:"8,515,767 km2"},
    {key:"Population", value:"210.14 million (2019)"},
    {key:"Capital", value:"Brasília"},
    {key:"Official Language(s)", value:"Portuguese"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"Jair Bolsonaro"},
    {key:"Vice President", value:"Hamilton Mourão"},
    {key:"GDP", value:"$3.596 trillion (2020)"},
    {key:"Currency", value:"Real (BRL)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+55"},
    {key:"ISO 3166 code", value:"BR"},
    {key:"Internal TLD", value:".br"}
   ];
});

southamericaDataApp.controller('chile-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Chile"},
    {key:"Size", value:"756,096 km2"},
    {key:"Population", value:"17.57 million (2017)"},
    {key:"Capital", value:"Santiagoa"},
    {key:"Official Language(s)", value:"Spanish"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"Sebastián Piñera"},
    {key:"GDP", value:"$503 billion (2019)"},
    {key:"Currency", value:"Peso (CLP)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+56"},
    {key:"ISO 3166 code", value:"CL"},
    {key:"Internal TLD", value:".cl"}
   ];
});

southamericaDataApp.controller('colombia-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Colombia"},
    {key:"Size", value:"1,141,748 km2"},
    {key:"Population", value:"48.25 million (2019)"},
    {key:"Capital", value:"Bogotá"},
    {key:"Official Language(s)", value:"Spanish"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"Iván Duque Márquez"},
    {key:"Vice President", value:"Marta Lucía Ramírez"},
    {key:"GDP", value:"$791.995 billion (2019)"},
    {key:"Currency", value:"Peso (COP)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+57"},
    {key:"ISO 3166 code", value:"CO"},
    {key:"Internal TLD", value:".co"}
   ];
});

southamericaDataApp.controller('cuba-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Cuba"},
    {key:"Size", value:"109,884 km2"},
    {key:"Population", value:"11.2 million (2018)"},
    {key:"Capital", value:"Havana"},
    {key:"Official Language(s)", value:"Spanish"},
    {key:"Government", value:"Marxist–Leninist, Socialist"},
    {key:"First Secretary", value:"Raúl Castro"},
    {key:"President", value:"Miguel Díaz-Canel"},
    {key:"GDP", value:"$791.995 billion (2019)"},
    {key:"Currency", value:"Peso (CUP), Convertible Peso (CUC)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+53"},
    {key:"ISO 3166 code", value:"CU"},
    {key:"Internal TLD", value:".cu"}
   ];
});

southamericaDataApp.controller('ecuador-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Ecuador"},
    {key:"Size", value:"283,561 km2"},
    {key:"Population", value:"17 million (2018)"},
    {key:"Capital", value:"Quito"},
    {key:"Official Language(s)", value:"Spanish"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"Lenín Moreno"},
    {key:"Vice President", value:"Otto Sonnenholzner"},
    {key:"GDP", value:"$202.043 billion (2019)"},
    {key:"Currency", value:"United States dollar (USD)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+593"},
    {key:"ISO 3166 code", value:"EC"},
    {key:"Internal TLD", value:".ec"}
   ];
});

southamericaDataApp.controller('falklandislands-info', function($scope) {
  $scope.info = [
    {key:"Sovereign state", value:"United Kingdom"},
    {key:"Size", value:"12,200 km2"},
    {key:"Population", value:"3,398 (2016)"},
    {key:"Capital", value:"Stanley"},
    {key:"Official Language(s)", value:"English"},
    {key:"Government", value:"Parliamentary, Monarchy"},
    {key:"Monarch", value:"Elizabeth II"},
    {key:"Governor", value:"Nigel Phillips"},
    {key:"GDP", value:"$228.5 million (2013)"},
    {key:"Currency", value:"Falklands pound (FKP)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+500"},
    {key:"ISO 3166 code", value:"FK"},
    {key:"Internal TLD", value:".fk"}
   ];
});

southamericaDataApp.controller('guyana-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Co-operative Republic of Guyana"},
    {key:"Size", value:"214,970 km2"},
    {key:"Population", value:"783,769 (2018)"},
    {key:"Capital", value:"Georgetown"},
    {key:"Official Language(s)", value:"English"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"David A. Granger"},
    {key:"Prime Minister", value:"Moses V. Nagamootoo"},
    {key:"GDP", value:"$13.506 billion (2020)"},
    {key:"Currency", value:"Guyanese dollar (GYD)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+592"},
    {key:"ISO 3166 code", value:"GY"},
    {key:"Internal TLD", value:".gy"}
   ];
});

southamericaDataApp.controller('paraguay-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Paraguay"},
    {key:"Size", value:"406,752 km2"},
    {key:"Population", value:"7 million (2019)"},
    {key:"Capital", value:"Asunción"},
    {key:"Official Language(s)", value:"Spanish, Guarani"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"Mario Abdo Benítez"},
    {key:"Vice President", value:"Hugo Velázquez"},
    {key:"GDP", value:"$101.075 billion (2019)"},
    {key:"Currency", value:"Guaraní (PYG)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+595"},
    {key:"ISO 3166 code", value:"PY"},
    {key:"Internal TLD", value:".py"}
   ];
});

southamericaDataApp.controller('peru-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Peru"},
    {key:"Size", value:"1,285,216 km2"},
    {key:"Population", value:" 32.82 million (2020)"},
    {key:"Capital", value:"Lima"},
    {key:"Official Language(s)", value:"Spanish"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"Martín Vizcarra"},
    {key:"Vice President", value:"Mercedes Aráoz"},
    {key:"Prime Minister", value:"Vicente Zeballos"},
    {key:"GDP", value:"$505.450 billion (2020)"},
    {key:"Currency", value:"Sol (PEN)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+51"},
    {key:"ISO 3166 code", value:"PE"},
    {key:"Internal TLD", value:".pe"}
   ];
});

southamericaDataApp.controller('suriname-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Suriname"},
    {key:"Size", value:"163,821 km2"},
    {key:"Population", value:"575,990 (2018)"},
    {key:"Capital", value:"Paramaribo"},
    {key:"Official Language(s)", value:"Dutch"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"Dési Bouterse"},
    {key:"Vice President", value:"Ashwin Adhin"},
    {key:"Prime Minister", value:"Ashwin Adhin"},
    {key:"GDP", value:"$9.044  billion (2019)"},
    {key:"Currency", value:"Surinamese dollar (SRD)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+597"},
    {key:"ISO 3166 code", value:"SR"},
    {key:"Internal TLD", value:".sr"}
   ];
});

southamericaDataApp.controller('uruguay-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Oriental Republic of Uruguay"},
    {key:"Size", value:"176,215 km2"},
    {key:"Population", value:"3.4 million (2018)"},
    {key:"Capital", value:"Montevideo"},
    {key:"Official Language(s)", value:"Spanish"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"Tabaré Vázquez"},
    {key:"Vice President", value:"Lucía Topolansky"},
    {key:"Prime Minister", value:"Ashwin Adhin"},
    {key:"GDP", value:"$86.562 billion (2020)"},
    {key:"Currency", value:"Uruguayan peso (UYU)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+598"},
    {key:"ISO 3166 code", value:"UY"},
    {key:"Internal TLD", value:".uy"}
   ];
});

southamericaDataApp.controller('venezuela-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Bolivarian Republic of Venezuela"},
    {key:"Size", value:"916,445 km2"},
    {key:"Population", value:"28.88 million (2018)"},
    {key:"Capital", value:"Caracas"},
    {key:"Official Language(s)", value:"Spanish"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"Nicolás Maduro"},
    {key:"Vice President", value:"Delcy Rodríguez"},
    {key:"Prime Minister", value:"Ashwin Adhin"},
    {key:"Currency", value:"Petro, Bolívar Soberano (VES)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+58"},
    {key:"ISO 3166 code", value:"VE"},
    {key:"Internal TLD", value:".ve"}
   ];
});
