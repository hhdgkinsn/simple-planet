// Themes
am4core.useTheme(am4themes_animated);

// Create map instance
var chart = am4core.create("map", am4maps.MapChart);

// Set map definition
chart.geodata = am4geodata_worldUltra;


// Set projection
chart.projection = new am4maps.projections.Eckert6();

// Zoom control
chart.zoomControl = new am4maps.ZoomControl();

// Reset Map
var homeButton = new am4core.Button();
homeButton.events.on("hit", function(){
  chart.goHome();
});

homeButton.icon = new am4core.Sprite();
homeButton.padding(7, 5, 7, 5);
homeButton.width = 30;
homeButton.icon.path = "M16,8 L14,8 L14,16 L10,16 L10,10 L6,10 L6,16 L2,16 L2,8 L0,8 L8,0 L16,8 Z M16,8";
homeButton.marginBottom = 10;
homeButton.parent = chart.zoomControl;
homeButton.insertBefore(chart.zoomControl.plusButton);

// Zoom level
chart.homeZoomLevel = 7.1;
chart.homeGeoPoint = { longitude: 13, latitude: 52 };


// Asia
var groupData = [
	{ "data": [{"id": "AL", "url": "/europe/countries/albania.html"}] },
	{ "data": [{"id": "AD", "url": "/europe/countries/andorra.html"}] },
	{ "data": [{"id": "AT", "url": "/europe/countries/austria.html"}] },
	{ "data": [{"id": "BY", "url": "/europe/countries/belarus.html"}] },
	{ "data": [{"id": "BE", "url": "/europe/countries/belgium.html"}] },
	{ "data": [{"id": "BA", "url": "/europe/countries/bosniaherzegovina.html"}] },
	{ "data": [{"id": "BG", "url": "/europe/countries/bulgaira.html"}] },
	{ "data": [{"id": "HR", "url": "/europe/countries/croatia.html"}] },
	{ "data": [{"id": "CY", "url": "/europe/countries/cyprus.html"}] },
	{ "data": [{"id": "CZ", "url": "/europe/countries/czechrepublic.html"}] },
	{ "data": [{"id": "DK", "url": "/europe/countries/denmark.html"}] },
	{ "data": [{"id": "EE", "url": "/europe/countries/estonia.html"}] },
	{ "data": [{"id": "FO", "url": "/europe/countries/foroeislands.html"}] },
	{ "data": [{"id": "FI", "url": "/europe/countries/finland.html"}] },
	{ "data": [{"id": "FR", "url": "/europe/countries/france.html"}] },
	{ "data": [{"id": "DE", "url": "/europe/countries/germany.html"}] },
	{ "data": [{"id": "GI", "url": "/europe/countries/gibraltar.html"}] },
	{ "data": [{"id": "GR", "url": "/europe/countries/greece.html"}] },
	{ "data": [{"id": "HU", "url": "/europe/countries/hungary.html"}] },
	{ "data": [{"id": "IS", "url": "/europe/countries/iceland.html"}] },
	{ "data": [{"id": "IE", "url": "/europe/countries/ireland.html"}] },
	{ "data": [{"id": "IM"}] },
	{ "data": [{"id": "IT", "url": "/europe/countries/italy.html"}] },
	{ "data": [{"id": "XK", "url": "/europe/countries/kosovo.html"}] },
	{ "data": [{"id": "LV", "url": "/europe/countries/latvia.html"}] },
	{ "data": [{"id": "LI", "url": "/europe/countries/lietchenstein.html"}] },
	{ "data": [{"id": "LT", "url": "/europe/countries/lithuania.html"}] },
	{ "data": [{"id": "LU", "url": "/europe/countries/luxembourg.html"}] },
	{ "data": [{"id": "MK", "url": "/europe/countries/macedonia.html"}] },
	{ "data": [{"id": "MT", "url": "/europe/countries/malta.html"}] },
	{ "data": [{"id": "MD", "url": "/europe/countries/moldova.html"}] },
	{ "data": [{"id": "MC", "url": "/europe/countries/monaco.html"}] },
	{ "data": [{"id": "ME", "url": "/europe/countries/montenegro.html"}] },
	{ "data": [{"id": "NL", "url": "/europe/countries/netherlands.html"}] },
	{ "data": [{"id": "NO", "url": "/europe/countries/norway.html"}] },
	{ "data": [{"id": "PL", "url": "/europe/countries/poland.html"}] },
	{ "data": [{"id": "PT", "url": "/europe/countries/portugal.html"}] },
	{ "data": [{"id": "RO", "url": "/europe/countries/romania.html"}] },
	{ "data": [{"id": "RU", "url": "/europe/countries/russia.html"}] },
	{ "data": [{"id": "SM", "url": "/europe/countries/sanmarino.html"}] },
	{ "data": [{"id": "RS", "url": "/europe/countries/serbia.html"}] },
	{ "data": [{"id": "SK", "url": "/europe/countries/slovakia.html"}] },
	{ "data": [{"id": "SI", "url": "/europe/countries/slovenia.html"}] },
	{ "data": [{"id": "ES", "url": "/europe/countries/spain.html"}] },
	{ "data": [{"id": "SE", "url": "/europe/countries/sweden.html"}] },
	{ "data": [{"id": "CH", "url": "/europe/countries/switzerland.html"}] },
	{ "data": [{"id": "UA", "url": "/europe/countries/ukraine.html"}] },
	{ "data": [{"id": "RU", "url": "/europe/countries/russia.html"}] },
	{ "data": [{"id": "GB", "url": "/europe/countries/uk.html"}] },
	{ "data": [{"id": "TR", "url": "/europe/countries/turkey.html"}] },
	{ "data": [{"id": "VA"}] },
  { "data": [{"id": "GG"}] },
  { "data": [{"id": "JE"}] },
  { "data": [{"id": "AX"}] },
  { "data": [{"id": "SJ"}] }
	];


var excludedCountries = ["AQ"];


groupData.forEach(function(group) {
  var series = chart.series.push(new am4maps.MapPolygonSeries());
  series.name = group.name;
  series.useGeodata = true;
  var includedCountries = [];
  group.data.forEach(function(country){
    includedCountries.push(country.id);
    excludedCountries.push(country.id);
  });
  series.include = includedCountries;

  series.fill = am4core.color("#c3d6a9");


  series.setStateOnChildren = true;
  var seriesHoverState = series.states.create("hover");


  var mapPolygonTemplate = series.mapPolygons.template;
  mapPolygonTemplate.fill = am4core.color("#a1d47f");
  mapPolygonTemplate.fillOpacity = 1;
  mapPolygonTemplate.nonScalingStroke = true;
  mapPolygonTemplate.stroke = am4core.color("#000");
  mapPolygonTemplate.strokeWidth = 0.1;
  mapPolygonTemplate.strokeOpacity = 1;
  mapPolygonTemplate.tooltipText = "{name}";
  mapPolygonTemplate.propertyFields.url = "url";

  var hoverState = mapPolygonTemplate.states.create("hover");
  hoverState.properties.fill = am4core.color("#8ec16c");


  series.data = JSON.parse(JSON.stringify(group.data));
});


// The rest of the world.
var worldSeries = chart.series.push(new am4maps.MapPolygonSeries());
var worldSeriesName = "world";
worldSeries.name = worldSeriesName;
worldSeries.useGeodata = true;
worldSeries.exclude = excludedCountries;
worldSeries.fillOpacity = 1;
worldSeries.mapPolygons.template.nonScalingStroke = true;

worldSeries.mapPolygons.template.stroke = worldSeries.mapPolygons.template.fill;
worldSeries.mapPolygons.template.strokeWidth = 0;
