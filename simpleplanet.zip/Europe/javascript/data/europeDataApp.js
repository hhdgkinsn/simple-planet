var europeDataApp = angular.module('europeDataApp', []);

europeDataApp.controller('europe-info', function($scope) {
  $scope.info = [
    {key:"Size", value:"10.18 million km²"},
    {key:"Population", value:"747.4 mil"},
    {key:"Number of countries", value:"44"},
    {key:"Largest Country", value:"Russia"},
    {key:"Smallest Country", value:"Vatican City"},
    {key:"Most populated country", value:"Russia"},
    {key:"Most Populated City", value:"Istanbul, Turkey"},
    {key:"Highest Point", value:"Mount Elbrus, Russia"}
   ];
});

europeDataApp.controller('albania-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Albania"},
    {key:"Size", value:"28,748 km2"},
    {key:"Population", value:"2.87 million (2017)"},
    {key:"Capital", value:"Tirana"},
    {key:"Official Language(s)", value:"Albanian"},
    {key:"Government", value:"Parlimentary"},
    {key:"President", value:"Ilir Meta"},
    {key:"Prime Minister", value:"Edi Rama"},
    {key:"GDP", value:"$42.594 billion (2020)"},
    {key:"Currency", value:"Lek (ALL)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+355"},
    {key:"ISO 3166 code", value:"AL"},
    {key:"Internal TLD", value:".al"}
   ];
});

europeDataApp.controller('andorra-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Principality of Andorra"},
    {key:"Size", value:"467.63 km2"},
    {key:"Population", value:"76,177 (2019)"},
    {key:"Capital", value:"Andorra la Vella"},
    {key:"Official Language(s)", value:"Catalan"},
    {key:"Government", value:"Parlimentary"},
    {key:"Co-princes", value:"Joan Enric Vives Sicília, Emmanuel Macron"},
    {key:"Prime Minister", value:"Xavier Espot Zamora"},
    {key:"GDP", value:"$3.237 billion (2018)"},
    {key:"Currency", value:"Euro (EUR)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+376"},
    {key:"ISO 3166 code", value:"AD"},
    {key:"Internal TLD", value:".ad"}
   ];
});

europeDataApp.controller('austria-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Austria"},
    {key:"Size", value:"83,879 km2"},
    {key:"Population", value:"8.9 million (2020)"},
    {key:"Capital", value:"Vienna"},
    {key:"Official Language(s)", value:"German"},
    {key:"Government", value:"Parlimentary"},
    {key:"President", value:"Alexander Van der Bellen"},
    {key:"GDP", value:"$461.432 billion (2018)"},
    {key:"Currency", value:"Euro (EUR)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+43"},
    {key:"ISO 3166 code", value:"AT"},
    {key:"Internal TLD", value:".at"}
   ];
});

europeDataApp.controller('belarus-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Belarus"},
    {key:"Size", value:"207,595 km2"},
    {key:"Population", value:"9.49 million (2018)"},
    {key:"Capital", value:"Minsk"},
    {key:"Official Language(s)", value:"Belarusian, Russian"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"Alexander Lukashenko"},
    {key:"Prime Minister", value:"Sergey Rumas"},
    {key:"GDP", value:"$195 billion (2019)"},
    {key:"Currency", value:"Belarusian ruble (BYN)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+375"},
    {key:"ISO 3166 code", value:"BY"},
    {key:"Internal TLD", value:".by"}
   ];
});

europeDataApp.controller('belgium-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Kingdom of Belgium"},
    {key:"Size", value:"30,689 km2"},
    {key:"Population", value:"11.51 million (2019)"},
    {key:"Capital", value:"Brussels"},
    {key:"Official Language(s)", value:"Dutch, French, German"},
    {key:"Government", value:"Parlimentary, Monarchy"},
    {key:"Monarch", value:"Philippe"},
    {key:"Prime Minister", value:"Sophie Wilmès"},
    {key:"GDP", value:"$550 billion (2018)"},
    {key:"Currency", value:"Euro (EUR)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+32"},
    {key:"ISO 3166 code", value:"BE"},
    {key:"Internal TLD", value:".be"}
   ];
});

europeDataApp.controller('bosniaherzegovina-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Bosnia and Herzegovina"},
    {key:"Size", value:"51,129 km2"},
    {key:"Population", value:"3.51 million (2016)"},
    {key:"Capital", value:"Sarajevo"},
    {key:"Language(s)", value:"Bosnian, Serbian, Croatian"},
    {key:"Government", value:"Parlimentary"},
    {key:"High Representative", value:"Valentin Inzko"},
    {key:"Chairman of the presidency", value:"Željko Komšić"},
    {key:"GDP", value:"$52.103 billion (2020)"},
    {key:"Currency", value:"Convertible mark (BAM)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+387"},
    {key:"ISO 3166 code", value:"BA"},
    {key:"Internal TLD", value:".ba"}
   ];
});

europeDataApp.controller('bulgaria-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Bulgaria"},
    {key:"Size", value:"110,993.6 km2"},
    {key:"Population", value:"7 million (2019)"},
    {key:"Capital", value:"Sofia"},
    {key:"Official Language(s)", value:"Bulgarian"},
    {key:"Government", value:"Parlimentary"},
    {key:"President", value:"Rumen Radev"},
    {key:"Prime Minister", value:"Boyko Borisov"},
    {key:"GDP", value:"$180.170 billion (2020)"},
    {key:"Currency", value:"Lev (BGN)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+359"},
    {key:"ISO 3166 code", value:"BG"},
    {key:"Internal TLD", value:".bg"}
   ];
});

europeDataApp.controller('croatia-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Croatia"},
    {key:"Size", value:"56,594 km2"},
    {key:"Population", value:"7 million (2019)"},
    {key:"Capital", value:"Zagreb"},
    {key:"Official Language(s)", value:"Croatian"},
    {key:"Government", value:"Parlimentary"},
    {key:"President", value:"Kolinda Grabar-Kitarović"},
    {key:"Prime Minister", value:"Andrej Plenković"},
    {key:"GDP", value:"$117.928 billion (2020)"},
    {key:"Currency", value:"Kuna (HRK)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+385"},
    {key:"ISO 3166 code", value:"HR"},
    {key:"Internal TLD", value:".hr"}
   ];
});

europeDataApp.controller('cyprus-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Cyprus"},
    {key:"Size", value:"9,251 km2"},
    {key:"Population", value:"1.18 million (2018)"},
    {key:"Capital", value:"Nicosia"},
    {key:"Official Language(s)", value:"Greek, Turkish"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"Nicos Anastasiades"},
    {key:"GDP", value:"$35.970 billion (2019)"},
    {key:"Currency", value:"Euro (EUR)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+357"},
    {key:"ISO 3166 code", value:"CY"},
    {key:"Internal TLD", value:".cy"}
   ];
});

europeDataApp.controller('czechrepublic-info', function($scope) {
  $scope.info = [
    {key:"Size", value:"78,866 km2"},
    {key:"Population", value:"10.64 million (2019)"},
    {key:"Capital", value:"Prague"},
    {key:"Official Language(s)", value:"Czech"},
    {key:"Government", value:"Parlimentary"},
    {key:"President", value:"Miloš Zeman"},
    {key:"President", value:"Andrej Babiš"},
    {key:"GDP", value:"$432.346 billion (2020)"},
    {key:"Currency", value:"Czech koruna (CZK)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+420"},
    {key:"ISO 3166 code", value:"CZ"},
    {key:"Internal TLD", value:".cz"}
   ];
});

europeDataApp.controller('denmark-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Kingdom of Denmark"},
    {key:"Size", value:"42,933 km2"},
    {key:"Population", value:"5.82 million (2019)"},
    {key:"Capital", value:"Copenhagen"},
    {key:"Official Language(s)", value:"Danish"},
    {key:"Government", value:"Parlimentary"},
    {key:"Monarch", value:"Margrethe II"},
    {key:"Prime Minister", value:"Mette Frederiksen"},
    {key:"GDP", value:"$299 billion (2018)"},
    {key:"Currency", value:"Danish krone (DKK)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+45"},
    {key:"ISO 3166 code", value:"DK"},
    {key:"Internal TLD", value:".dk"}
   ];
});

europeDataApp.controller('estonia-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic Of Estonia"},
    {key:"Size", value:"45,227 km2"},
    {key:"Population", value:"1.32 million (2020)"},
    {key:"Capital", value:"Tallinn"},
    {key:"Official Language(s)", value:"Estonian"},
    {key:"Government", value:"Parlimentary"},
    {key:"President", value:"Kersti Kaljulaid"},
    {key:"Prime Minister", value:"Jüri Ratas"},
    {key:"GDP", value:"$49.644 billion (2020)"},
    {key:"Currency", value:"Euro (EUR)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+372"},
    {key:"ISO 3166 code", value:"EE"},
    {key:"Internal TLD", value:".ee"}
   ];
});

europeDataApp.controller('faroeislands-info', function($scope) {
  $scope.info = [
    {key:"Sovereign state", value:"Denmark"},
    {key:"Size", value:"1,399 km2"},
    {key:"Population", value:"51,783 (2019)"},
    {key:"Capital", value:"Tórshavn"},
    {key:"Official Language(s)", value:"Faroese, Danish"},
    {key:"Government", value:"Parlimentary, Monarchy"},
    {key:"Monarch", value:"Margrethe II"},
    {key:"High Commissioner", value:"Lene Moyell Johansen"},
    {key:"Prime Minister", value:"Bárður á Steig Nielsen"},
    {key:"GDP", value:"$3 billion (2017)"},
    {key:"Currency", value:"Faroese króna (DKK)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+298"},
    {key:"ISO 3166 code", value:"FO"},
    {key:"Internal TLD", value:".fo"}
   ];
});

europeDataApp.controller('finland-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Finland"},
    {key:"Size", value:"338,424 km2"},
    {key:"Population", value:"5.52 million (2019)"},
    {key:"Capital", value:"Helsinki"},
    {key:"Official Language(s)", value:"Finnish, Swedish"},
    {key:"Government", value:"Parlimentary"},
    {key:"President", value:"Sauli Niinistö"},
    {key:"Prime Minister", value:"Sanna Marin"},
    {key:"GDP", value:"$257 billion (2018)"},
    {key:"Currency", value:"Euro (EUR)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+358"},
    {key:"ISO 3166 code", value:"FI"},
    {key:"Internal TLD", value:".fi"}
   ];
});

europeDataApp.controller('france-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"French Republic"},
    {key:"Size", value:"640,679 km2"},
    {key:"Population", value:"67 million (2019)"},
    {key:"Capital", value:"Paris"},
    {key:"Official Language(s)", value:"French"},
    {key:"Government", value:"Semi-presidential"},
    {key:"President", value:"Emmanuel Macron"},
    {key:"Prime Minister", value:"Édouard Philippe"},
    {key:"GDP", value:"$3.161 trillion (2020)"},
    {key:"Currency", value:"Euro (EUR), CFP franc (XPF)​"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+33"},
    {key:"ISO 3166 code", value:"FR"},
    {key:"Internal TLD", value:".fr"}
   ];
});

europeDataApp.controller('germany-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Federal Republic of Germany"},
    {key:"Size", value:"357,386 km2"},
    {key:"Population", value:"83.14 million (2019)"},
    {key:"Capital", value:"Berlin"},
    {key:"Official Language(s)", value:"German"},
    {key:"Government", value:"Parlimentary"},
    {key:"President", value:"Frank-Walter Steinmeier"},
    {key:"Chancellor", value:"Angela Merkel"},
    {key:"GDP", value:"$4.444 trillion (2020)"},
    {key:"Currency", value:"Euro (EUR)​"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+49"},
    {key:"ISO 3166 code", value:"DE"},
    {key:"Internal TLD", value:".de"}
   ];
});

europeDataApp.controller('gibraltar-info', function($scope) {
  $scope.info = [
    {key:"Sovereign state", value:"United Kingdom"},
    {key:"Size", value:"6.7 km2"},
    {key:"Population", value:"32,194 (2015)"},
    {key:"Capital", value:"Gibraltar"},
    {key:"Official Language(s)", value:"English"},
    {key:"Government", value:"Dependancy"},
    {key:"Monarch", value:"Elizabeth II"},
    {key:"Governor", value:"Ed Davis"},
    {key:"GDP", value:"£1.64 billion (2013)"},
    {key:"Currency", value:"Gibraltar pound (GIP)​"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+350"},
    {key:"ISO 3166 code", value:"GI"},
    {key:"Internal TLD", value:".gi"}
   ];
});

europeDataApp.controller('greece-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Hellenic Republic"},
    {key:"Size", value:"131,957 km2"},
    {key:"Population", value:"10.76 million (2017)"},
    {key:"Capital", value:"Athens"},
    {key:"Official Language(s)", value:"Greek"},
    {key:"Government", value:"Parlimentary"},
    {key:"President", value:"Prokopis Pavlopoulos"},
    {key:"Prime Minister", value:"Kyriakos Mitsotakis"},
    {key:"GDP", value:"$337.900 billion (2020)"},
    {key:"Currency", value:"Euro (EUR)​"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+30"},
    {key:"ISO 3166 code", value:"GR"},
    {key:"Internal TLD", value:".gr"}
   ];
});

europeDataApp.controller('guernsey-info', function($scope) {
  $scope.info = [
    {key:"Sovereign state", value:"United Kingdom"},
    {key:"Size", value:"65 km2"},
    {key:"Population", value:"63,026 (2016)"},
    {key:"Capital", value:"Gibraltar"},
    {key:"Official Language(s)", value:"English"},
    {key:"Government", value:"Parlimentary, Monarchy"},
    {key:"Monarch", value:"Elizabeth II"},
    {key:"Governor", value:"Ian Corder"},
    {key:"GDP", value:"$3.474 billion (2015)"},
    {key:"Currency", value:"Guernsey pound, Pound sterling (GBP)​"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+44"},
    {key:"ISO 3166 code", value:"GG"},
    {key:"Internal TLD", value:".gg"}
   ];
});

europeDataApp.controller('hungary-info', function($scope) {
  $scope.info = [
    {key:"Size", value:"93,030 km2"},
    {key:"Population", value:"9.77 million (2019)"},
    {key:"Capital", value:"Budapest"},
    {key:"Official Language(s)", value:"Hungarian"},
    {key:"Government", value:"Parlimentary"},
    {key:"President", value:"János Áder"},
    {key:"Prime Minister", value:"Viktor Orbán"},
    {key:"GDP", value:"$350 billion (2020)"},
    {key:"Currency", value:"Forint (HUF)​"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+36"},
    {key:"ISO 3166 code", value:"HU"},
    {key:"Internal TLD", value:".hu"}
   ];
});

europeDataApp.controller('iceland-info', function($scope) {
  $scope.info = [
    {key:"Size", value:"102,775 km2"},
    {key:"Population", value:"10.76 million (2017)"},
    {key:"Capital", value:"Reykjavík"},
    {key:"Official Language(s)", value:"Greek"},
    {key:"Government", value:"Parlimentary"},
    {key:"President", value:"Guðni Th. Jóhannesson"},
    {key:"Prime Minister", value:"Katrín Jakobsdóttir"},
    {key:"GDP", value:"$19 billion (2018)"},
    {key:"Currency", value:"Icelandic króna (ISK)​"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+354"},
    {key:"ISO 3166 code", value:"IS"},
    {key:"Internal TLD", value:".is"}
   ];
});

europeDataApp.controller('ireland-info', function($scope) {
  $scope.info = [
    {key:"Size", value:"84,421 km²"},
    {key:"Population", value:"4.83 million (2018)"},
    {key:"Capital", value:"Dublin"},
    {key:"Official Language(s)", value:"Irish, English"},
    {key:"Government", value:"Parlimentary"},
    {key:"President", value:"Michael D. Higgins"},
    {key:"Prime Minister", value:"Leo Varadkar"},
    {key:"GDP", value:"$412.797 billion (2019)"},
    {key:"Currency", value:"Euro (EUR)​"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+353"},
    {key:"ISO 3166 code", value:"IE"},
    {key:"Internal TLD", value:".ie"}
   ];
});

europeDataApp.controller('italy-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Italian Republic"},
    {key:"Size", value:"301,340 km2"},
    {key:"Population", value:"60.35 million (2018)"},
    {key:"Capital", value:"Rome"},
    {key:"Official Language(s)", value:"English"},
    {key:"Government", value:"Parlimentary"},
    {key:"President", value:"Sergio Mattarella"},
    {key:"Prime Minister", value:"Giuseppe Conte"},
    {key:"GDP", value:"$2.443 trillion (2019)"},
    {key:"Currency", value:"Euro (EUR)​"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+39"},
    {key:"ISO 3166 code", value:"IT"},
    {key:"Internal TLD", value:".it"}
   ];
});

europeDataApp.controller('latvia-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Latvia"},
    {key:"Size", value:"64,589 km2"},
    {key:"Population", value:"1.91 million (2018)"},
    {key:"Capital", value:"Riga"},
    {key:"Official Language(s)", value:"Latvian"},
    {key:"Government", value:"Parlimentary"},
    {key:"President", value:"Egils Levits"},
    {key:"Prime Minister", value:"Krišjānis Kariņš"},
    {key:"GDP", value:"$63.490 billion (2020)"},
    {key:"Currency", value:"Euro (EUR)​"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+371"},
    {key:"ISO 3166 code", value:"LV"},
    {key:"Internal TLD", value:".lv"}
   ];
});

europeDataApp.controller('liechtenstein-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Principality of Liechtenstein"},
    {key:"Size", value:"160 km2"},
    {key:"Population", value:"38,557 (2019)"},
    {key:"Capital", value:"Vaduz"},
    {key:"Official Language(s)", value:"German"},
    {key:"Government", value:"Parlimentary, Monarchy"},
    {key:"Monarch", value:"Hans-Adam II"},
    {key:"Prime Minister", value:"Adrian Hasler"},
    {key:"GDP", value:"$5.3 billion (2013)"},
    {key:"Currency", value:"Swiss franc (CHF)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+423"},
    {key:"ISO 3166 code", value:"LI"},
    {key:"Internal TLD", value:".li"}
   ];
});

europeDataApp.controller('lithuania-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Lithuania"},
    {key:"Size", value:"65,300 km2"},
    {key:"Population", value:"2.79 million (2020)"},
    {key:"Capital", value:"Vilnius"},
    {key:"Official Language(s)", value:"Lithuanian"},
    {key:"Government", value:"Semi-presidential"},
    {key:"President", value:"Gitanas Nausėda"},
    {key:"Prime Minister", value:"Saulius Skvernelis"},
    {key:"GDP", value:"$107 billion (2020)"},
    {key:"Currency", value:"Euro (EUR)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+370"},
    {key:"ISO 3166 code", value:"LT"},
    {key:"Internal TLD", value:".lt"}
   ];
});

europeDataApp.controller('luxembourg-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Grand Duchy of Luxembourg"},
    {key:"Size", value:"2,586.4 km2"},
    {key:"Population", value:"613,894 (2019)"},
    {key:"Capital", value:"Luxembourg City"},
    {key:"Official Language(s)", value:"Luxembourgish, French, German"},
    {key:"Government", value:"Parlimentary"},
    {key:"Monarch", value:"Henri"},
    {key:"Prime Minister", value:"Xavier Bettel"},
    {key:"GDP", value:"$66.848 billion (2019)"},
    {key:"Currency", value:"Euro (EUR)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+352"},
    {key:"ISO 3166 code", value:"LU"},
    {key:"Internal TLD", value:".lu"}
   ];
});

europeDataApp.controller('malta-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Malta"},
    {key:"Size", value:"316 km2"},
    {key:"Population", value:"493,559 (2019)"},
    {key:"Capital", value:"Valletta"},
    {key:"Official Language(s)", value:"Maltese, English"},
    {key:"Government", value:"Parlimentary"},
    {key:"President", value:"George Vella"},
    {key:"Prime Minister", value:"Robert Abela"},
    {key:"GDP", value:"$22.802 billion (2019)"},
    {key:"Currency", value:"Euro (EUR)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+356"},
    {key:"ISO 3166 code", value:"MT"},
    {key:"Internal TLD", value:".mt"}
   ];
});

europeDataApp.controller('moldova-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Moldova"},
    {key:"Size", value:"33,846 km2"},
    {key:"Population", value:"2.68 million (2019)"},
    {key:"Capital", value:"Chișinău"},
    {key:"Official Language(s)", value:"Romanian"},
    {key:"Government", value:"Parlimentary"},
    {key:"President", value:"Igor Dodon"},
    {key:"Prime Minister", value:"Ion Chicu"},
    {key:"GDP", value:"$27.271 billion (2019)"},
    {key:"Currency", value:"Leu (MDL)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+373"},
    {key:"ISO 3166 code", value:"MD"},
    {key:"Internal TLD", value:".md"}
   ];
});

europeDataApp.controller('monaco-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Principality of Monaco"},
    {key:"Size", value:"2.2 km2"},
    {key:"Population", value:"2.68 million (2019)"},
    {key:"Capital", value:"Monaco City"},
    {key:"Official Language(s)", value:"French"},
    {key:"Government", value:"Parlimentary, Monarchy"},
    {key:"Monarch", value:"Albert II"},
    {key:"Minister of state", value:"Serge Telle"},
    {key:"GDP", value:"$7.672 billion (2015)"},
    {key:"Currency", value:"Euro (EUR)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+377"},
    {key:"ISO 3166 code", value:"MC"},
    {key:"Internal TLD", value:".mc"}
   ];
});

europeDataApp.controller('netherlands-info', function($scope) {
  $scope.info = [
    {key:"Size", value:"41,873 km2"},
    {key:"Population", value:"17.42 million (2019)"},
    {key:"Capital", value:"Amsterdam"},
    {key:"Official Language(s)", value:"Dutch"},
    {key:"Government", value:"Parlimentary, Monarchy"},
    {key:"Monarch", value:"Willem-Alexander"},
    {key:"Prime Minister", value:"Mark Rutte"},
    {key:"GDP", value:"$1.004 trillion (2019)"},
    {key:"Currency", value:"Euro (EUR), US dollar (USD)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+377"},
    {key:"ISO 3166 code", value:"NL"},
    {key:"Internal TLD", value:".nl"}
   ];
});

europeDataApp.controller('northmacedonia-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of North Macedonia"},
    {key:"Size", value:"25,713 km2"},
    {key:"Population", value:"2 million (2019)"},
    {key:"Capital", value:"Skopje"},
    {key:"Official Language(s)", value:"Macedonian, Albanian"},
    {key:"Government", value:"Parlimentary"},
    {key:"President", value:"Stevo Pendarovski"},
    {key:"Prime Minister", value:"Oliver Spasovski"},
    {key:"GDP", value:"$33.822 billion (2019)"},
    {key:"Currency", value:"Macedonian denar (MKD)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+389"},
    {key:"ISO 3166 code", value:"MK"},
    {key:"Internal TLD", value:".mk"}
   ];
});

europeDataApp.controller('norway-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Kingdom of Norway"},
    {key:"Size", value:"385,207 km2"},
    {key:"Population", value:"5.35 million (2019)"},
    {key:"Capital", value:"Oslo"},
    {key:"Official Language(s)", value:"Norwegian, Sámi"},
    {key:"Government", value:"Parlimentary, Monarchy"},
    {key:"Monarch", value:"Harald V"},
    {key:"Prime Minister", value:"Erna Solberg"},
    {key:"GDP", value:"$397 billion (2018)"},
    {key:"Currency", value:"Norwegian krone (NOK)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+47"},
    {key:"ISO 3166 code", value:"NO"},
    {key:"Internal TLD", value:".no"}
   ];
});

europeDataApp.controller('poland-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Poland"},
    {key:"Size", value:"312,696 km2"},
    {key:"Population", value:"38.38 million (2019)"},
    {key:"Capital", value:"Warsaw"},
    {key:"Official Language(s)", value:"Polish"},
    {key:"Government", value:"Semi-presidential"},
    {key:"President", value:"Andrzej Duda"},
    {key:"Prime Minister", value:"Mateusz Morawiecki"},
    {key:"GDP", value:"$1.353 trillion (2020)"},
    {key:"Currency", value:"Polish złoty (PLN)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+48"},
    {key:"ISO 3166 code", value:"PL"},
    {key:"Internal TLD", value:".pl"}
   ];
});

europeDataApp.controller('portugal-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Portuguese Republic"},
    {key:"Size", value:"92,212 km2"},
    {key:"Population", value:"10.27 million (2018)"},
    {key:"Capital", value:"Lisbon"},
    {key:"Official Language(s)", value:"Portuguese"},
    {key:"Government", value:"Semi-presidential"},
    {key:"President", value:"Marcelo Rebelo de Sousa"},
    {key:"Prime Minister", value:"António Costa"},
    {key:"GDP", value:"$358 billion (2020)"},
    {key:"Currency", value:"Euro (EUR)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+351"},
    {key:"ISO 3166 code", value:"PT"},
    {key:"Internal TLD", value:".pt"}
   ];
});

europeDataApp.controller('romania-info', function($scope) {
  $scope.info = [
    {key:"Size", value:"238,397 km2"},
    {key:"Population", value:"19.4 million (2019)"},
    {key:"Capital", value:"Bucharest"},
    {key:"Official Language(s)", value:"Romanian"},
    {key:"Government", value:"Semi-presidential"},
    {key:"President", value:"Klaus Iohannis"},
    {key:"Prime Minister", value:"Ludovic Orban"},
    {key:"GDP", value:"$576.946 billion (2020)"},
    {key:"Currency", value:"Romanian leu (RON)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+40"},
    {key:"ISO 3166 code", value:"RO"},
    {key:"Internal TLD", value:".ro"}
   ];
});

europeDataApp.controller('sanmarino-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of San Marino"},
    {key:"Size", value:"61.2 km2"},
    {key:"Population", value:"10.27 million (2018)"},
    {key:"Capital", value:"San Marino"},
    {key:"Official Language(s)", value:"Portuguese"},
    {key:"Government", value:"Parlimentary"},
    {key:"Captains Regent", value:"Luca Boschi, Mariella Mularoni"},
    {key:"GDP", value:"$2.09 billion (2017)"},
    {key:"Currency", value:"Euro (EUR)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+378"},
    {key:"ISO 3166 code", value:"SM"},
    {key:"Internal TLD", value:".sm"}
   ];
});

europeDataApp.controller('serbia-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Serbia"},
    {key:"Size", value:"88,361 km2"},
    {key:"Population", value:"10.27 million (2018)"},
    {key:"Capital", value:"Belgrade"},
    {key:"Official Language(s)", value:"Serbian"},
    {key:"Government", value:"Parlimentary"},
    {key:"President", value:"Aleksandar Vučić"},
    {key:"Prime Minister", value:"Ana Brnabić"},
    {key:"GDP", value:"$137.294 billion (2020)"},
    {key:"Currency", value:"Serbian dinar (RSD)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+381"},
    {key:"ISO 3166 code", value:"RS"},
    {key:"Internal TLD", value:".rs"}
   ];
});

europeDataApp.controller('slovakia-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Slovak Republic"},
    {key:"Size", value:"49,035 km2"},
    {key:"Population", value:"5.45 million (2018)"},
    {key:"Capital", value:"Bratislava"},
    {key:"Official Language(s)", value:"Slovak"},
    {key:"Government", value:"Zuzana Čaputová"},
    {key:"President", value:"Peter Pellegrini"},
    {key:"Prime Minister", value:"Ana Brnabić"},
    {key:"GDP", value:"$209.186 billion (2020)"},
    {key:"Currency", value:"Euro (EUR)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+421"},
    {key:"ISO 3166 code", value:"SK"},
    {key:"Internal TLD", value:".sk"}
   ];
});

europeDataApp.controller('slovenia-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Slovenia"},
    {key:"Size", value:"20,273 km2"},
    {key:"Population", value:"2 million (2019)"},
    {key:"Capital", value:"Ljubljana"},
    {key:"Official Language(s)", value:"Slovene"},
    {key:"Government", value:"Parlimentary"},
    {key:"President", value:"Borut Pahor"},
    {key:"Prime Minister", value:"Marjan Šarec"},
    {key:"GDP", value:"$83 billion (2020)"},
    {key:"Currency", value:"Euro (EUR)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+386"},
    {key:"ISO 3166 code", value:"SI"},
    {key:"Internal TLD", value:".si"}
   ];
});

europeDataApp.controller('spain-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Kingdom of Spain"},
    {key:"Size", value:"505,990 km2"},
    {key:"Population", value:"46.73 million (2018)"},
    {key:"Capital", value:"Madrid"},
    {key:"Official Language(s)", value:"Spanish"},
    {key:"Government", value:"Parlimentary, Monarchy"},
    {key:"Monarch", value:"Felipe VI"},
    {key:"Prime Minister", value:"Pedro Sánchez"},
    {key:"GDP", value:"$2.016 trillion (2020)"},
    {key:"Currency", value:"Euro (EUR)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+34"},
    {key:"ISO 3166 code", value:"ES"},
    {key:"Internal TLD", value:".es"}
   ];
});

europeDataApp.controller('svalbard-info', function($scope) {
  $scope.info = [
    {key:"Sovereign state", value:"Norway"},
    {key:"Size", value:"61,022 km2"},
    {key:"Population", value:"2,667 (2016)"},
    {key:"Capital", value:"Madrid"},
    {key:"Official Language(s)", value:"Spanish"},
    {key:"Government", value:"Locally administered, Monarchy"},
    {key:"Monarch", value:"Harald V"},
    {key:"Governor", value:"Kjerstin Askholt"},
    {key:"GDP", value:"$2.016 trillion (2020)"},
    {key:"Currency", value:"Norwegian krone (NOK)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+47"},
    {key:"ISO 3166 code", value:"SJ"},
    {key:"Internal TLD", value:".sj"}
   ];
});

europeDataApp.controller('sweden-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Kingdom of Sweden"},
    {key:"Size", value:"450,295 km2"},
    {key:"Population", value:"10.3 million (2019)"},
    {key:"Capital", value:"Stockholm"},
    {key:"Official Language(s)", value:"Swedish"},
    {key:"Government", value:"Parlimentary, Monarchy"},
    {key:"Monarch", value:"Carl XVI Gustaf"},
    {key:"Prime Minister", value:"Stefan Löfven"},
    {key:"GDP", value:"$563.882 billion (2019)"},
    {key:"Currency", value:"Swedish krona (SEK)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+46"},
    {key:"ISO 3166 code", value:"SE"},
    {key:"Internal TLD", value:".se"}
   ];
});

europeDataApp.controller('switzerland-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Swiss Confederation"},
    {key:"Size", value:"41,285 km2"},
    {key:"Population", value:"8.57 million (2019)"},
    {key:"Capital", value:"Bern"},
    {key:"Official Language(s)", value:"German, French, Italian, Romansh"},
    {key:"Government", value:"Parlimentary, Directorial"},
    {key:"President", value:"Simonetta Sommaruga"},
    {key:"Vice-president", value:"Guy Parmelin"},
    {key:"GDP", value:"$548 billion (2018)"},
    {key:"Currency", value:"Swiss franc (CHF)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+41"},
    {key:"ISO 3166 code", value:"CH"},
    {key:"Internal TLD", value:".ch"}
   ];
});

europeDataApp.controller('turkey-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Turkey"},
    {key:"Size", value:"783,356 km2"},
    {key:"Population", value:"82 million (2018)"},
    {key:"Capital", value:"Ankara"},
    {key:"Official Language(s)", value:"Turkish"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"Recep Tayyip Erdoğan"},
    {key:"Vice-president", value:"Fuat Oktay"},
    {key:"GDP", value:"$2.464 trillion (2020)"},
    {key:"Currency", value:"Turkish lira (TRY)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+90"},
    {key:"ISO 3166 code", value:"TR"},
    {key:"Internal TLD", value:".tr"}
   ];
});

europeDataApp.controller('uk-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"United Kingdom of Great Britain and Northern Ireland"},
    {key:"Size", value:"242,495 km2"},
    {key:"Population", value:"67.54 million (2019)"},
    {key:"Capital", value:"London"},
    {key:"Official Language(s)", value:"English"},
    {key:"Government", value:"Parlimentary, Monarchy"},
    {key:"Monarch", value:"	Elizabeth II"},
    {key:"Prime Minister", value:"Boris Johnson"},
    {key:"GDP", value:"$3.131 trillion (2019)"},
    {key:"Currency", value:"Pound sterling (GBP)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+44"},
    {key:"ISO 3166 code", value:"GB"},
    {key:"Internal TLD", value:".gb"}
   ];
});

europeDataApp.controller('ukraine-info', function($scope) {
  $scope.info = [
    {key:"Size", value:"603,628 km2"},
    {key:"Population", value:"42 million (2019)"},
    {key:"Capital", value:"Kiev"},
    {key:"Official Language(s)", value:"Ukrainian"},
    {key:"Government", value:"Semi-presidential"},
    {key:"President", value:"Volodymyr Zelensky"},
    {key:"Prime Ministe", value:"Oleksiy Honcharuk"},
    {key:"GDP", value:"$408.040 billion (2019)"},
    {key:"Currency", value:"Ukrainian hryvnia (UAH)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+380"},
    {key:"ISO 3166 code", value:"UA"},
    {key:"Internal TLD", value:".ua"}
   ];
});
