
// Themes
am4core.useTheme(am4themes_animated);

// Create map instance
var chart = am4core.create("map", am4maps.MapChart);

// Set map definition
chart.geodata = am4geodata_worldUltra;


// Set projection
chart.projection = new am4maps.projections.Miller();

// Zoom control
chart.zoomControl = new am4maps.ZoomControl();

// Reset Map
var homeButton = new am4core.Button();
homeButton.events.on("hit", function(){
  chart.goHome();
});

homeButton.icon = new am4core.Sprite();
homeButton.padding(7, 5, 7, 5);
homeButton.width = 30;
homeButton.icon.path = "M16,8 L14,8 L14,16 L10,16 L10,10 L6,10 L6,16 L2,16 L2,8 L0,8 L8,0 L16,8 Z M16,8";
homeButton.marginBottom = 10;
homeButton.parent = chart.zoomControl;
homeButton.insertBefore(chart.zoomControl.plusButton);

// Zoom level
chart.homeZoomLevel = 10;
chart.homeGeoPoint = { longitude: 180, latitude: -18 };
// Rotation
chart.deltaLongitude = -160;


// Asia
var groupData = [
	{ "data": [{"id": "AS", "url": "/oceania/countries/americansomoa.html"}] },
	{ "data": [{"id": "AU", "url": "/oceania/countries/australia.html"}] },
  { "data": [{"id": "CX", "url": "/oceania/countries/christmasisland.html"}] },
	{ "data": [{"id": "CK", "url": "/oceania/countries/cookislands.html"}] },
	{ "data": [{"id": "FJ", "url": "/oceania/countries/fiji.html"}] },
	{ "data": [{"id": "PF", "url": "/oceania/countries/frenchpolynesia.html"}] },
	{ "data": [{"id": "GU", "url": "/oceania/countries/guam.html"}] },
	{ "data": [{"id": "KI", "url": "/oceania/countries/kiribati.html"}] },
	{ "data": [{"id": "MH", "url": "/oceania/countries/marshallislands.html"}] },
	{ "data": [{"id": "FM", "url": "/oceania/countries/micronesia.html"}] },
	{ "data": [{"id": "NR", "url": "/oceania/countries/nauru.html"}] },
	{ "data": [{"id": "NC", "url": "/oceania/countries/newcaledonia.html"}] },
	{ "data": [{"id": "NZ", "url": "/oceania/countries/newzealand.html"}] },
	{ "data": [{"id": "NU", "url": "/oceania/countries/niue.html"}] },
	{ "data": [{"id": "NF", "url": "/oceania/countries/norfolkislands.html"}] },
	{ "data": [{"id": "MP", "url": "/oceania/countries/northernmarianaislands.html"}] },
	{ "data": [{"id": "PW", "url": "/oceania/countries/palau.html"}] },
	{ "data": [{"id": "PG", "url": "/oceania/countries/papuanewguinea.html"}] },
	{ "data": [{"id": "PN", "url": "/oceania/countries/pitcairnislands.html"}] },
	{ "data": [{"id": "WS", "url": "/oceania/countries/samoa.html"}] },
	{ "data": [{"id": "SB", "url": "/oceania/countries/solomonislands.html"}] },
	{ "data": [{"id": "TK", "url": "/oceania/countries/tokelau.html"}] },
	{ "data": [{"id": "TV", "url": "/oceania/countries/tuvalu.html"}] },
	{ "data": [{"id": "VU", "url": "/oceania/countries/vanuatu.html"}] }
	];


var excludedCountries = ["AQ"];


groupData.forEach(function(group) {
  var series = chart.series.push(new am4maps.MapPolygonSeries());
  series.name = group.name;
  series.useGeodata = true;
  var includedCountries = [];
  group.data.forEach(function(country){
    includedCountries.push(country.id);
    excludedCountries.push(country.id);
  });
  series.include = includedCountries;

  series.fill = am4core.color("#fff");


  series.setStateOnChildren = true;
  var seriesHoverState = series.states.create("hover");


  var mapPolygonTemplate = series.mapPolygons.template;
  mapPolygonTemplate.fill = am4core.color("#a1d47f");
  mapPolygonTemplate.fillOpacity = 1;
  mapPolygonTemplate.nonScalingStroke = false;
  mapPolygonTemplate.stroke = am4core.color("#000");
  mapPolygonTemplate.strokeWidth = 0.2;
  mapPolygonTemplate.strokeOpacity = 0.5;
  mapPolygonTemplate.tooltipText = "{name}";
  mapPolygonTemplate.propertyFields.url = "url";

  var hoverState = mapPolygonTemplate.states.create("hover");
  hoverState.properties.fill = am4core.color("#8ec16c");


  series.data = JSON.parse(JSON.stringify(group.data));
});


// The rest of the world.
var worldSeries = chart.series.push(new am4maps.MapPolygonSeries());
var worldSeriesName = "world";
worldSeries.name = worldSeriesName;
worldSeries.useGeodata = true;
worldSeries.exclude = excludedCountries;
worldSeries.fillOpacity = 1;
worldSeries.mapPolygons.template.nonScalingStroke = true;

worldSeries.mapPolygons.template.stroke = worldSeries.mapPolygons.template.fill;
worldSeries.mapPolygons.template.strokeWidth = 0;
