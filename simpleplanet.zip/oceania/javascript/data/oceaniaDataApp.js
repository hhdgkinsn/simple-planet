var oceaniaDataApp = angular.module('oceaniaDataApp', []);

oceaniaDataApp.controller('oceania-info', function($scope) {
  $scope.info = [
    {key:"Size", value:"10.18 million km²"},
    {key:"Population", value:"747.4 mil"},
    {key:"Number of countries", value:"44"},
    {key:"Largest Country", value:"Russia"},
    {key:"Smallest Country", value:"Vatican City"},
    {key:"Most populated country", value:"Russia"},
    {key:"Most Populated City", value:"Istanbul, Turkey"},
    {key:"Highest Point", value:"Mount Elbrus, Russia"}
   ];
});

oceaniaDataApp.controller('americansamoa-info', function($scope) {
  $scope.info = [
    {key:"Size", value:"199 km2"},
    {key:"Population", value:"55,689 (2018)"},
    {key:"Capital", value:"Pago Pago"},
    {key:"Official Language(s)", value:"English, Samoan"},
    {key:"Government", value:"Presidential, Dependency"},
    {key:"President", value:"	Donald Trump"},
    {key:"Governor", value:"Lolo Matalasi Moliga"},
    {key:"GDP", value:"$658 million (2016)"},
    {key:"Currency", value:"United States dollar (USD)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+1-684"},
    {key:"ISO 3166 code", value:"AS"},
    {key:"Internal TLD", value:".as"}
   ];
});

oceaniaDataApp.controller('australia-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Commonwealth of Australia"},
    {key:"Size", value:"7,692,024 km2"},
    {key:"Population", value:"25.61 million (2020)"},
    {key:"Capital", value:"Canberra"},
    {key:"Official Language(s)", value:"English"},
    {key:"Government", value:"Parliamentary, Monarchy"},
    {key:"Monarch", value:"Elizabeth II"},
    {key:"Governor-general", value:"David Hurley"},
    {key:"GDP", value:"$1.365 trillion (2019)"},
    {key:"Currency", value:"Australian dollar (AUD)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+61"},
    {key:"ISO 3166 code", value:"AU"},
    {key:"Internal TLD", value:".au"}
   ];
});

oceaniaDataApp.controller('cookislands-info', function($scope) {
  $scope.info = [
    {key:"Size", value:"236.7 km2"},
    {key:"Population", value:"17,518 (2018)"},
    {key:"Capital", value:"Avarua"},
    {key:"Official Language(s)", value:"English, Cook Islands Māori"},
    {key:"Government", value:"Monarchy"},
    {key:"Monarch", value:"Elizabeth II"},
    {key:"Queen's Representative", value:"Tom Marsters"},
    {key:"Prime minister", value:"Henry Puna"},
    {key:"GDP", value:"$311 million (2014)"},
    {key:"Currency", value:"New Zealand dollar (NZD), Cook Islands dollar"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+682"},
    {key:"ISO 3166 code", value:"CK"},
    {key:"Internal TLD", value:".ck"}
   ];
});

oceaniaDataApp.controller('fiji-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Fiji"},
    {key:"Size", value:"18,274 km2"},
    {key:"Population", value:"926,276 (2018)"},
    {key:"Capital", value:"Suva"},
    {key:"Official Language(s)", value:"iTaukei, English, Fiji Hindi"},
    {key:"Government", value:"Parliamentary"},
    {key:"President", value:"Jioji Konrote"},
    {key:"Prime minister", value:"Frank Bainimarama"},
    {key:"Prime minister", value:"Henry Puna"},
    {key:"GDP", value:"$5.223 billion (2018)"},
    {key:"Currency", value:"Fijian dollar (FJD)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+679"},
    {key:"ISO 3166 code", value:"FJ"},
    {key:"Internal TLD", value:".fj"}
   ];
});

oceaniaDataApp.controller('frenchpolynesia-info', function($scope) {
  $scope.info = [
    {key:"Sovereign state", value:"France"},
    {key:"Size", value:"4,167 km2"},
    {key:"Population", value:"275,918 (2017)"},
    {key:"Capital", value:"Papeete"},
    {key:"Official Language(s)", value:"French"},
    {key:"Government", value:"Parliamentary, Dependency"},
    {key:"President of the French republic", value:"Emmanuel Macron"},
    {key:"President of French Polynesia", value:"Édouard Fritch"},
    {key:"Prime minister", value:"Henry Puna"},
    {key:"GDP", value:"$6.163 billion (2018)"},
    {key:"Currency", value:"CFP franc (XPF)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+689"},
    {key:"ISO 3166 code", value:"PF"},
    {key:"Internal TLD", value:".pf"}
   ];
});

oceaniaDataApp.controller('guam-info', function($scope) {
  $scope.info = [
    {key:"Sovereign state", value:"United states"},
    {key:"Size", value:"540 km2"},
    {key:"Population", value:"162,742 (2016)"},
    {key:"Capital", value:"Hagåtña"},
    {key:"Official Language(s)", value:"English, Chamorro"},
    {key:"Government", value:"Presidential, Dependency"},
    {key:"President", value:"Donald Trump"},
    {key:"Governor", value:"Lou Leon Guerrero"},
    {key:"Prime minister", value:"Henry Puna"},
    {key:"GDP", value:"$5.79 billion (2016)"},
    {key:"Currency", value:"United States dollar (USD)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+1-671"},
    {key:"ISO 3166 code", value:"GU"},
    {key:"Internal TLD", value:".gu"}
   ];
});

oceaniaDataApp.controller('kiribati-info', function($scope) {
  $scope.info = [
    {key:"Oficially", value:"Republic of Kiribati"},
    {key:"Size", value:"811 km2"},
    {key:"Population", value:"110,136 (2015)"},
    {key:"Capital", value:"Tarawa"},
    {key:"Official Language(s)", value:"English, Gilbertese"},
    {key:"Government", value:"Parliamentary, Executive presidency"},
    {key:"President", value:"Taneti Maamau"},
    {key:"Vice-president", value:"Teuea Toatu"},
    {key:"Prime minister", value:"Henry Puna"},
    {key:"GDP", value:"$250 million (2019)"},
    {key:"Currency", value:"Kiribati dollar, Australian dollar (AUD)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+686"},
    {key:"ISO 3166 code", value:"KI"},
    {key:"Internal TLD", value:".ki"}
   ];
});

oceaniaDataApp.controller('marshallislands-info', function($scope) {
  $scope.info = [
    {key:"Oficially", value:"Republic of the Marshall Islands"},
    {key:"Size", value:"181.43 km2"},
    {key:"Population", value:"58,413 (2018)"},
    {key:"Capital", value:"Majuro"},
    {key:"Official Language(s)", value:"English, Marshallese"},
    {key:"Government", value:"Parliamentary"},
    {key:"President", value:"David Kabua"},
    {key:"Prime minister", value:"Henry Puna"},
    {key:"GDP", value:"$215 million (2019)"},
    {key:"Currency", value:"United States dollar (USD)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+692"},
    {key:"ISO 3166 code", value:"MH"},
    {key:"Internal TLD", value:".mh"}
   ];
});

oceaniaDataApp.controller('micronesia-info', function($scope) {
  $scope.info = [
    {key:"Oficially", value:"Federated States of Micronesia"},
    {key:"Size", value:"702 km2"},
    {key:"Population", value:"112,640 (2018)"},
    {key:"Capital", value:"Palikir"},
    {key:"Official Language(s)", value:"English"},
    {key:"Government", value:"Parliamentary"},
    {key:"President", value:"David Panuelo"},
    {key:"Vice President", value:"Yosiwo George"},
    {key:"GDP", value:"$367 million (2019)"},
    {key:"Currency", value:"United States dollar (USD)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+691"},
    {key:"ISO 3166 code", value:"FM"},
    {key:"Internal TLD", value:".fm"}
   ];
});

oceaniaDataApp.controller('nauru-info', function($scope) {
  $scope.info = [
    {key:"Oficially", value:"Republic of Nauru"},
    {key:"Size", value:"21 km2"},
    {key:"Population", value:"11,200 (2018)"},
    {key:"Capital", value:"Yaren"},
    {key:"Official Language(s)", value:"Nauruan, English"},
    {key:"Government", value:"Parliamentary"},
    {key:"President", value:"Lionel Aingimea"},
    {key:"GDP", value:"$160 million (2017)"},
    {key:"Currency", value:"Australian dollar (AUD)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+674"},
    {key:"ISO 3166 code", value:"NR"},
    {key:"Internal TLD", value:".nr"}
   ];
});

oceaniaDataApp.controller('newcaledonia-info', function($scope) {
  $scope.info = [
    {key:"Sovereign state", value:"France"},
    {key:"Size", value:"18,576 km2"},
    {key:"Population", value:"282,200 (2018)"},
    {key:"Capital", value:"Nouméa"},
    {key:"Official Language(s)", value:"French"},
    {key:"Government", value:"Parliamentary"},
    {key:"President of France", value:"Emmanuel Macron"},
    {key:"President of New Caledonia", value:"Thierry Santa"},
    {key:"Prime Minister", value:"Édouard Philippe"},
    {key:"GDP", value:"$9.89 billion (2011)"},
    {key:"Currency", value:"CFP franc (XPF)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+687"},
    {key:"ISO 3166 code", value:"NC"},
    {key:"Internal TLD", value:".nc"}
   ];
});

oceaniaDataApp.controller('newzealand-info', function($scope) {
  $scope.info = [
    {key:"Size", value:"268,021 km2"},
    {key:"Population", value:"4.95 million (2020)"},
    {key:"Capital", value:"Wellington"},
    {key:"Official Language(s)", value:"English, Māori"},
    {key:"Government", value:"Parliamentary, Monarchy"},
    {key:"Monarchy", value:"Elizabeth II"},
    {key:"Governor-General", value:"Patsy Reddy"},
    {key:"Prime Minister", value:"Jacinda Ardern"},
    {key:"GDP", value:"$199 billion (2018)"},
    {key:"Currency", value:"New Zealand dollar (NZD)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+64"},
    {key:"ISO 3166 code", value:"NZ"},
    {key:"Internal TLD", value:".nz"}
   ];
});

oceaniaDataApp.controller('niue-info', function($scope) {
  $scope.info = [
    {key:"Size", value:"261.46 km2"},
    {key:"Population", value:"1,620 (2018)"},
    {key:"Capital", value:"Alofi"},
    {key:"Official Language(s)", value:"English, Niuean"},
    {key:"Government", value:"Parliamentary, Monarchy"},
    {key:"Monarchy", value:"Elizabeth II"},
    {key:"Governor-General", value:"Dame Patricia Reddy"},
    {key:"GDP", value:"$199 billion (2018)"},
    {key:"Currency", value:"New Zealand dollar (NZD)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+683"},
    {key:"ISO 3166 code", value:"NU"},
    {key:"Internal TLD", value:".nu"}
   ];
});

oceaniaDataApp.controller('norfolkisland-info', function($scope) {
  $scope.info = [
    {key:"Sovereign state", value:"Australia"},
    {key:"Size", value:"34.6 km2"},
    {key:"Population", value:"1,748 (2016)"},
    {key:"Capital", value:"Kingston"},
    {key:"Official Language(s)", value:"English, Norfuk"},
    {key:"Government", value:"Dependency"},
    {key:"Monarchy", value:"Elizabeth II"},
    {key:"Governor-General", value:"David Hurley"},
    {key:"GDP", value:"$199 billion (2018)"},
    {key:"Currency", value:"Australian dollar (AUD)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+672"},
    {key:"ISO 3166 code", value:"NF"},
    {key:"Internal TLD", value:".nf"}
   ];
});

oceaniaDataApp.controller('northernmarianaislands-info', function($scope) {
  $scope.info = [
    {key:"Oficially", value:"Commonwealth of the Northern Mariana Islands"},
    {key:"Size", value:"464 km2"},
    {key:"Population", value:"55,144 (2017)"},
    {key:"Capital", value:"Saipan"},
    {key:"Official Language(s)", value:"English, Chamorro, Carolinian"},
    {key:"Government", value:"Dependency"},
    {key:"President of the United States", value:"Donald Trump"},
    {key:"Governor", value:"Ralph Torres"},
    {key:"GDP", value:"$1.24 billion (2016)"},
    {key:"Currency", value:"United States dollar (USD)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+1-670"},
    {key:"ISO 3166 code", value:"MP"},
    {key:"Internal TLD", value:".mp"}
   ];
});

oceaniaDataApp.controller('palau-info', function($scope) {
  $scope.info = [
    {key:"Oficially", value:"Republic of Palau"},
    {key:"Size", value:"459 km2"},
    {key:"Population", value:"17,907 (2018)"},
    {key:"Capital", value:"Ngerulmud"},
    {key:"Official Language(s)", value:"English, Japanese, Sonsorolese, Tobian"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"Tommy Remengesau"},
    {key:"Vice-president", value:"Raynold Oilouch"},
    {key:"GDP", value:"$300 million (2018)"},
    {key:"Currency", value:"United States dollar (USD)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+690"},
    {key:"ISO 3166 code", value:"PW"},
    {key:"Internal TLD", value:".pw"}
   ];
});

oceaniaDataApp.controller('papuanewguinea-info', function($scope) {
  $scope.info = [
    {key:"Oficially", value:"Independent State of Papua New Guinea"},
    {key:"Size", value:"462,840 km2"},
    {key:"Population", value:"8.6 million (2018)"},
    {key:"Capital", value:"Port Moresby"},
    {key:"Official Language(s)", value:"English, Hiri Motu, Tok Pisin"},
    {key:"Government", value:"Parliamentary, Monarchy"},
    {key:"Monarch", value:"	Elizabeth II"},
    {key:"Governor-General", value:"Bob Dadae"},
    {key:"Prime Minister", value:"James Marape"},
    {key:"GDP", value:"	$32.382 billion (2019)"},
    {key:"Currency", value:"Papua New Guinean kina (PGK)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+675"},
    {key:"ISO 3166 code", value:"PG"},
    {key:"Internal TLD", value:".pg"}
   ];
});

oceaniaDataApp.controller('pitcairnislands-info', function($scope) {
  $scope.info = [
    {key:"Sovereign state", value:"United Kingdom"},
    {key:"Size", value:"47 km2"},
    {key:"Population", value:"50 (2019)"},
    {key:"Capital", value:"Adamstown"},
    {key:"Official Language(s)", value:"English, Pitkern"},
    {key:"Government", value:"Dependency"},
    {key:"Monarch", value:"	Elizabeth II"},
    {key:"Governor", value:"Laura Clarke"},
    {key:"Currency", value:"New Zealand dollar (NZD)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+64"},
    {key:"ISO 3166 code", value:"PN"},
    {key:"Internal TLD", value:".pn"}
   ];
});

oceaniaDataApp.controller('samoa-info', function($scope) {
  $scope.info = [
    {key:"Oficially", value:"Independent State of Samoa"},
    {key:"Size", value:"2,842 km2 "},
    {key:"Population", value:"195,843 (2016)"},
    {key:"Capital", value:"Apia"},
    {key:"Official Language(s)", value:"English, Samoan"},
    {key:"Government", value:"Parliamentary, Monarchy"},
    {key:"Chieftain of the Government", value:"Va'aletoa Sualauvi II"},
    {key:"Prime Minister", value:"Tuilaepa Aiono Sailele Malielegaoi"},
    {key:"GDP", value:"$1.188 billion (2018)"},
    {key:"Currency", value:"Tālā (WST)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+665"},
    {key:"ISO 3166 code", value:"WS"},
    {key:"Internal TLD", value:".ws"}
   ];
});

oceaniaDataApp.controller('solomonislands-info', function($scope) {
  $scope.info = [
    {key:"Size", value:"28,400 km2"},
    {key:"Population", value:"652,857 (2018)"},
    {key:"Capital", value:"Honiara"},
    {key:"Official Language(s)", value:"English"},
    {key:"Government", value:"Parliamentary, Monarchy"},
    {key:"Monarch", value:"Elizabeth II"},
    {key:"Governor-General", value:"	David Vunagi"},
    {key:"Prime Minister", value:"Manasseh Sogavare"},
    {key:"GDP", value:"$1.479 billion (2019)"},
    {key:"Currency", value:"Solomon Islands dollar (SBD)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+677"},
    {key:"ISO 3166 code", value:"SB"},
    {key:"Internal TLD", value:".sb"}
   ];
});

oceaniaDataApp.controller('tokelau-info', function($scope) {
  $scope.info = [
    {key:"Sovereign state", value:"New Zealand"},
    {key:"Size", value:"10 km2"},
    {key:"Population", value:"1,499 (2016)"},
    {key:"Capital", value:"None"},
    {key:"Official Language(s)", value:"Tokelauan, English"},
    {key:"Government", value:"Dependency"},
    {key:"Monarch", value:"Elizabeth II"},
    {key:"Administrator", value:"Ross Ardern"},
    {key:"GDP", value:"$10 million (2017)"},
    {key:"Currency", value:"New Zealand dollar (NZD)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+690"},
    {key:"ISO 3166 code", value:"TK"},
    {key:"Internal TLD", value:".tk"}
   ];
});

oceaniaDataApp.controller('tonga-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Kingdom of Tonga"},
    {key:"Size", value:"748 km2"},
    {key:"Population", value:"100,651 (2016)"},
    {key:"Capital", value:"Nukuʻalofa"},
    {key:"Official Language(s)", value:"English, Tongan"},
    {key:"Government", value:"Parliamentary, Monarchy"},
    {key:"Monarch", value:"Tupou VI"},
    {key:"Prime Minister", value:"	Pohiva Tuʻiʻonetoa"},
    {key:"GDP", value:"$655 million (2019)"},
    {key:"Currency", value:"Paʻanga (TOP)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+676"},
    {key:"ISO 3166 code", value:"TO"},
    {key:"Internal TLD", value:".to"}
   ];
});

oceaniaDataApp.controller('tuvalu-info', function($scope) {
  $scope.info = [
    {key:"Size", value:"26 km2"},
    {key:"Population", value:"11,192 (2017)"},
    {key:"Capital", value:"Funafuti"},
    {key:"Official Language(s)", value:"English, Tuvaluan"},
    {key:"Government", value:"Parliamentary, Monarchy"},
    {key:"Monarch", value:"Elizabeth II"},
    {key:"Governor-General", value:"Iakoba Italeli"},
    {key:"Prime Minister", value:"Kausea Natano"},
    {key:"GDP", value:"$39 million (2016)"},
    {key:"Currency", value:"Tuvaluan dollar, Australian dollar (AUD)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+688"},
    {key:"ISO 3166 code", value:"TV"},
    {key:"Internal TLD", value:".tv"}
   ];
});

oceaniaDataApp.controller('vanuatu-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Vanuatu"},
    {key:"Size", value:"12,189 km2"},
    {key:"Population", value:"272,459 (2016)"},
    {key:"Capital", value:"Port Vila"},
    {key:"Official Language(s)", value:"Bislama, English, French"},
    {key:"Government", value:"Parliamentary"},
    {key:"President", value:"Tallis Obed Moses"},
    {key:"Prime Minister", value:"Charlot Salwai"},
    {key:"GDP", value:"$820 million (2018)"},
    {key:"Currency", value:"Vanuatu vatu (VUV)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+678"},
    {key:"ISO 3166 code", value:"VU"},
    {key:"Internal TLD", value:".vu"}
   ];
});

oceaniaDataApp.controller('wallisfutuna-info', function($scope) {
  $scope.info = [
    {key:"Sovereign state", value:"France"},
    {key:"Size", value:"142.42 km2"},
    {key:"Population", value:"11,558 (2018)"},
    {key:"Capital", value:"Matā'Utu"},
    {key:"Official Language(s)", value:"French"},
    {key:"Government", value:"Dependency"},
    {key:"President of France", value:"Emmanuel Macron"},
    {key:"Administrator Superior", value:"Thierry Queffelec"},
    {key:"GDP", value:"$188 million (2005)"},
    {key:"Currency", value:"CFP franc (XPF)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+681"},
    {key:"ISO 3166 code", value:"WF"},
    {key:"Internal TLD", value:".wf"}
   ];
});
