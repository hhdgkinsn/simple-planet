var worldDataApp = angular.module('worldDataApp', []);


worldDataApp.controller('world-info', function($scope) {
  $scope.info = [
    {key:"Size", value:"6,371 km"},
    {key:"Population", value:"7.7 bil"},
    {key:"Number of continents", value:"7"},
    {key:"Number of countries", value:"197"},
    {key:"Largest Country", value:"Russia"},
    {key:"Smallest Country", value:"Vatican City"},
    {key:"Most populated country", value:"China"},
    {key:"Least populated country", value:"Vatican City"},
    {key:"Largest City", value:"Tokyo, Japan"},
    {key:"Most Populated City", value:"Tokyo, Japan"},
    {key:"Highest Point", value:"Mount Everest (8,850 m)"},
    {key:"Lowest Point", value:"Challenger Deep (10,994 m)"}
   ];
});
