// Themes
am4core.useTheme(am4themes_animated);

// Create map instance
var chart = am4core.create("map", am4maps.MapChart);

// Set map definition
chart.geodata = am4geodata_worldUltra;


// Set projection
chart.projection = new am4maps.projections.Mercator();

// Series for World map
var worldSeries = chart.series.push(new am4maps.MapPolygonSeries());
worldSeries.exclude = ["AQ"];
worldSeries.useGeodata = true;

var polygonTemplate = worldSeries.mapPolygons.template;
polygonTemplate.tooltipText = "{name}";
polygonTemplate.fill = am4core.color("#a1d47f");
polygonTemplate.stroke = am4core.color("#000");
polygonTemplate.strokeWidth = 0.4;
polygonTemplate.strokeOpacity = 0.4;
polygonTemplate.nonScalingStroke = true;

// Hover state
var hs = polygonTemplate.states.create("hover");
hs.properties.fill = am4core.color("#8ec16c");

// Zoom control
chart.zoomControl = new am4maps.ZoomControl();

// Reset Map
var homeButton = new am4core.Button();
homeButton.events.on("hit", function(){
  chart.goHome();
});

homeButton.icon = new am4core.Sprite();
homeButton.padding(7, 5, 7, 5);
homeButton.width = 30;
homeButton.icon.path = "M16,8 L14,8 L14,16 L10,16 L10,10 L6,10 L6,16 L2,16 L2,8 L0,8 L8,0 L16,8 Z M16,8";
homeButton.marginBottom = 10;
homeButton.parent = chart.zoomControl;
homeButton.insertBefore(chart.zoomControl.plusButton);




// Africa
// var groupData = [
// 	{ "data": [{"id": "DZ", "url": "/explore/countries-portal/africa/countries/algeria.html"}] },
// 	{ "data": [{"id": "AO", "url": "/explore/countries-portal/africa/countries/angola.html"}] },
// 	{ "data": [{"id": "BJ", "url": "/explore/countries-portal/africa/countries/benin.html"}] },
// 	{ "data": [{"id": "BW", "url": "/explore/countries-portal/africa/countries/botswana.html"}] },
// 	{ "data": [{"id": "BF", "url": "/explore/countries-portal/africa/countries/burkina-faso.html"}] },
// 	{ "data": [{"id": "BI", "url": "/explore/countries-portal/africa/countries/burundi.html"}] },
// 	{ "data": [{"id": "CM", "url": "/explore/countries-portal/africa/countries/cameroon.html"}] },
// 	{ "data": [{"id": "CV", "url": "/explore/countries-portal/africa/countries/cape-verde.html"}] },
// 	{ "data": [{"id": "CF", "url": "/explore/countries-portal/africa/countries/c.a.r.html"}] },
// 	{ "data": [{"id": "KM", "url": "/explore/countries-portal/africa/countries/comoros.html"}] },
// 	{ "data": [{"id": "CD", "url": "/explore/countries-portal/africa/countries/congo(d.c.r).html"}] },
// 	{ "data": [{"id": "DJ", "url": "/explore/countries-portal/africa/countries/djibouti.html"}] },
// 	{ "data": [{"id": "EG", "url": "/explore/countries-portal/africa/countries/egypt.html"}] },
// 	{ "data": [{"id": "GQ", "url": "/explore/countries-portal/africa/countries/eq-guinea.html"}] },
// 	{ "data": [{"id": "ER", "url": "/explore/countries-portal/africa/countries/eritrea.html"}] },
// 	{ "data": [{"id": "ET", "url": "/explore/countries-portal/africa/countries/ethiopia.html"}] },
// 	{ "data": [{"id": "GA", "url": "/explore/countries-portal/africa/countries/gabon.html"}] },
// 	{ "data": [{"id": "GM", "url": "/explore/countries-portal/africa/countries/gambia.html"}] },
// 	{ "data": [{"id": "GH", "url": "/explore/countries-portal/africa/countries/ghana.html"}] },
// 	{ "data": [{"id": "GN", "url": "/explore/countries-portal/africa/countries/guinea.html"}] },
// 	{ "data": [{"id": "GW", "url": "/explore/countries-portal/africa/countries/guinea-bissau.html"}] },,
// 	{ "data": [{"id": "CI", "url": "/explore/countries-portal/africa/countries/ivory-coast.html"}] },
// 	{ "data": [{"id": "KE", "url": "/explore/countries-portal/africa/countries/kenya.html"}] },
// 	{ "data": [{"id": "LS", "url": "/explore/countries-portal/africa/countries/lesotho.html"}] },,
// 	{ "data": [{"id": "LR", "url": "/explore/countries-portal/africa/countries/liberia.html"}] },
// 	{ "data": [{"id": "LY", "url": "/explore/countries-portal/africa/countries/libya.html"}] },
// 	{ "data": [{"id": "MG", "url": "/explore/countries-portal/africa/countries/madagascar.html"}] },
// 	{ "data": [{"id": "MW", "url": "/explore/countries-portal/africa/countries/malawi.html"}] },
// 	{ "data": [{"id": "ML", "url": "/explore/countries-portal/africa/countries/mali.html"}] },
// 	{ "data": [{"id": "MR", "url": "/explore/countries-portal/africa/countries/mauritania.html"}] },
// 	{ "data": [{"id": "MU", "url": "/explore/countries-portal/africa/countries/mauritius.html"}] },
// 	{ "data": [{"id": "MA", "url": "/explore/countries-portal/africa/countries/morocco.html"}] },
// 	{ "data": [{"id": "MZ", "url": "/explore/countries-portal/africa/countries/mozambique.html"}] },
// 	{ "data": [{"id": "NA", "url": "/explore/countries-portal/africa/countries/namibia.html"}] },
// 	{ "data": [{"id": "NE", "url": "/explore/countries-portal/africa/countries/niger.html"}] },,
// 	{ "data": [{"id": "NG", "url": "/explore/countries-portal/africa/countries/nigeria.html"}] },
// 	{ "data": [{"id": "CG", "url": "/explore/countries-portal/africa/countries/congo.html"}] },
// 	{ "data": [{"id": "RE", "url": "/explore/countries-portal/africa/countries/reunion.html"}] },
// 	{ "data": [{"id": "RW", "url": "/explore/countries-portal/africa/countries/rwanda.html"}] },
// 	{ "data": [{"id": "SH", "url": "/explore/countries-portal/africa/countries/saint-helena.html"}] },
// 	{ "data": [{"id": "ST", "url": "/explore/countries-portal/africa/countries/sao-tome-principe.html"}] },
// 	{ "data": [{"id": "SN", "url": "/explore/countries-portal/africa/countries/senegal.html"}] },
// 	{ "data": [{"id": "SC", "url": "/explore/countries-portal/africa/countries/seychelles.html"}] },
// 	{ "data": [{"id": "SL", "url": "/explore/countries-portal/africa/countries/sierra-leone.html"}] },
// 	{ "data": [{"id": "SO", "url": "/explore/countries-portal/africa/countries/somalia.html"}] },
// 	{ "data": [{"id": "ZA", "url": "/explore/countries-portal/africa/countries/south-africa.html"}] },
// 	{ "data": [{"id": "SS", "url": "/explore/countries-portal/africa/countries/south-sudan.html"}] },
// 	{ "data": [{"id": "SD", "url": "/explore/countries-portal/africa/countries/sudan.html"}] },
// 	{ "data": [{"id": "SZ", "url": "/explore/countries-portal/africa/countries/eswatini.html"}] },
// 	{ "data": [{"id": "TZ", "url": "/explore/countries-portal/africa/countries/tanzania.html"}] },
// 	{ "data": [{"id": "TG", "url": "/explore/countries-portal/africa/countries/togo.html"}] },
// 	{ "data": [{"id": "TN", "url": "/explore/countries-portal/africa/countries/tunisia.html"}] },
// 	{ "data": [{"id": "UG", "url": "/explore/countries-portal/africa/countries/uganda.html"}] },
// 	{ "data": [{"id": "EH", "url": "/explore/countries-portal/africa/countries/western-sahara.html"}] },
// 	{ "data": [{"id": "YT", "url": "/explore/countries-portal/africa/countries/mayotte.html"}] },
// 	{ "data": [{"id": "ZM", "url": "/explore/countries-portal/africa/countries/zambia.html"}] },
// 	{ "data": [{"id": "ZW", "url": "/explore/countries-portal/africa/countries/zimbabwe.html"}] },
// 	{ "data": [{"id": "TD", "url": "/explore/countries-portal/africa/countries/chad.html"}] }
// 	];


// var excludedCountries = ["AQ"];


// groupData.forEach(function(group) {
//   var series = chart.series.push(new am4maps.MapPolygonSeries());
//   series.name = group.name;
//   series.useGeodata = true;
//   var includedCountries = [];
//   group.data.forEach(function(country){
//     includedCountries.push(country.id);
//     excludedCountries.push(country.id);
//   });
//   series.include = includedCountries;

//   series.fill = am4core.color("#fff");


//   series.setStateOnChildren = true;
//   var seriesHoverState = series.states.create("hover");


//   var mapPolygonTemplate = series.mapPolygons.template;
//   mapPolygonTemplate.fill = am4core.color("#fff");
//   mapPolygonTemplate.fillOpacity = 1;
//   mapPolygonTemplate.nonScalingStroke = true;
//   mapPolygonTemplate.stroke = am4core.color("#878787");
//   mapPolygonTemplate.strokeWidth = 0.2;
//   mapPolygonTemplate.strokeOpacity = 0.5;
//   mapPolygonTemplate.tooltipText = "{name}";
//   mapPolygonTemplate.propertyFields.url = "url";


//   var hoverState = mapPolygonTemplate.states.create("hover");
//   hoverState.properties.fill = am4core.color("#a3cc88");

//   series.data = JSON.parse(JSON.stringify(group.data));

// });


// // The rest of the world.
// var worldSeries = chart.series.push(new am4maps.MapPolygonSeries());
// var worldSeriesName = "world";
// worldSeries.name = worldSeriesName;
// worldSeries.useGeodata = true;
// worldSeries.exclude = excludedCountries;
// worldSeries.fillOpacity = 0.3;
// worldSeries.mapPolygons.template.nonScalingStroke = true;

// worldSeries.mapPolygons.template.stroke = worldSeries.mapPolygons.template.fill;
// worldSeries.mapPolygons.template.strokeWidth = 0;



// ------------------------ Mini Orthographic Globe ------------------------


// Create map instance
var globe = am4core.create("mini-globe", am4maps.MapChart);

globe.deltaLongitude = -15;
// chart.deltaLatitude = 10;

// Set map definition
globe.geodata = am4geodata_worldLow;

// Set projection
globe.projection = new am4maps.projections.Orthographic();

var polygonSeries = new am4maps.MapPolygonSeries();
polygonSeries.useGeodata = true;
globe.series.push(polygonSeries);

var polygonTemplate = polygonSeries.mapPolygons.template;
polygonTemplate.fill = am4core.color("#a1d47f");
polygonTemplate.fillOpacity = 1;

polygonTemplate.strokeWidth = 0;

globe.seriesContainer.draggable = false;
globe.seriesContainer.resizable = false;
