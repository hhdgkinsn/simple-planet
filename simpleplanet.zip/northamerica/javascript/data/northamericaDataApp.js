var northamericaDataApp = angular.module('northamericaDataApp', []);

northamericaDataApp.controller('northamerica-info', function($scope) {
  $scope.info = [
    {key:"Size", value:" 24.71 million km²"},
    {key:"Population", value:"579 mil"},
    {key:"Number of countries", value:"23"},
    {key:"Largest Country", value:"Canada"},
    {key:"Smallest Country", value:"Saint Kitts and Nevis"},
    {key:"Most populated country", value:"USA"},
    {key:"Most Populated City", value:"Mexico City, Mexico"},
    {key:"Highest Point", value:"Mount McKinley, USA"}
   ];
});

northamericaDataApp.controller('anguilla-info', function($scope) {
  $scope.info = [
    {key:"Size", value:"91 km2"},
    {key:"Population", value:"14,731 (2018)"},
    {key:"Capital", value:"Tirana"},
    {key:"Official Language(s)", value:"English"},
    {key:"Government", value:"Parlimentary, Monarchy"},
    {key:"Monarch", value:"Elizabeth II"},
    {key:"Governer", value:"Tim Foy"},
    {key:"GDP", value:"$311 million (2014)"},
    {key:"Currency", value:"Eastern Caribbean dollar (XCD)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+1-264"},
    {key:"ISO 3166 code", value:"AI"},
    {key:"Internal TLD", value:".ai"}
   ];
});

northamericaDataApp.controller('antiguabarbuda-info', function($scope) {
  $scope.info = [
    {key:"Size", value:"440 km2"},
    {key:"Population", value:"96,286 (2018)"},
    {key:"Capital", value:"Tirana"},
    {key:"Official Language(s)", value:"English"},
    {key:"Government", value:"Parlimentary, Monarchy"},
    {key:"Monarch", value:"Elizabeth II"},
    {key:"Governer-General", value:"Rodney Williams"},
    {key:"Prime minister", value:"Gaston Browne"},
    {key:"GDP", value:"$2.731 billion (2019)"},
    {key:"Currency", value:"East Caribbean dollar (XCD)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+1-268"},
    {key:"ISO 3166 code", value:"AG"},
    {key:"Internal TLD", value:".ag"}
   ];
});

northamericaDataApp.controller('barbados-info', function($scope) {
  $scope.info = [
    {key:"Size", value:"439 km2"},
    {key:"Population", value:"277,821 (2010)"},
    {key:"Capital", value:"Bridgetown"},
    {key:"Official Language(s)", value:"English"},
    {key:"Government", value:"Parlimentary, Monarchy"},
    {key:"Monarch", value:"Elizabeth II"},
    {key:"Governer-General", value:"Sandra Mason"},
    {key:"Prime minister", value:"Mia Mottley"},
    {key:"GDP", value:"$5.398 billion (2019)"},
    {key:"Currency", value:"Barbadian dollar (BBD)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+1-246"},
    {key:"ISO 3166 code", value:"BB"},
    {key:"Internal TLD", value:".bb"}
   ];
});

northamericaDataApp.controller('belize-info', function($scope) {
  $scope.info = [
    {key:"Size", value:"22,966 km2"},
    {key:"Population", value:"408,487 (2019)"},
    {key:"Capital", value:"Belmopan"},
    {key:"Official Language(s)", value:"English"},
    {key:"Government", value:"Parlimentary, Monarchy"},
    {key:"Monarch", value:"Elizabeth II"},
    {key:"Governer-General", value:"Colville Young"},
    {key:"Prime minister", value:"Dean Barrow"},
    {key:"GDP", value:"$3.484 billion (2019)"},
    {key:"Currency", value:"Belize dollar (BZD)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+501"},
    {key:"ISO 3166 code", value:"BZ"},
    {key:"Internal TLD", value:".bz"}
   ];
});

northamericaDataApp.controller('bermuda-info', function($scope) {
  $scope.info = [
    {key:"Size", value:"53.2 km2"},
    {key:"Population", value:"71,176 (2018)"},
    {key:"Capital", value:"Hamilton"},
    {key:"Official Language(s)", value:"English"},
    {key:"Government", value:"Parlimentary, Monarchy"},
    {key:"Monarch", value:"Elizabeth II"},
    {key:"Governer", value:"John Rankin"},
    {key:"GDP", value:"$5.853 billion (2017)"},
    {key:"Currency", value:"Bermudian dollar (BMD)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+1-441"},
    {key:"ISO 3166 code", value:"BM"},
    {key:"Internal TLD", value:".bm"}
   ];
});

northamericaDataApp.controller('britishvirginislands-info', function($scope) {
  $scope.info = [
    {key:"Size", value:"153 km2"},
    {key:"Population", value:"31,758 (2018)"},
    {key:"Capital", value:"Road Town"},
    {key:"Official Language(s)", value:"English"},
    {key:"Government", value:"Parlimentary, Monarchy"},
    {key:"Monarch", value:"Elizabeth II"},
    {key:"Governer", value:"Augustus Jaspert"},
    {key:"GDP", value:"$500 million (2017)"},
    {key:"Currency", value:"United States dollar (USD)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+1-284"},
    {key:"ISO 3166 code", value:"VG"},
    {key:"Internal TLD", value:".vg"}
   ];
});

northamericaDataApp.controller('canada-info', function($scope) {
  $scope.info = [
    {key:"Size", value:"9,984,670 km2"},
    {key:"Population", value:"37.79 (2019)"},
    {key:"Capital", value:"Ottawa"},
    {key:"Official Language(s)", value:"English, French"},
    {key:"Government", value:"Parlimentary, Monarchy"},
    {key:"Monarch", value:"Elizabeth II"},
    {key:"Governer", value:"Julie Payette"},
    {key:"Prime minister", value:"Justin Trudeau"},
    {key:"GDP", value:"$1.900 trillion (2019)"},
    {key:"Currency", value:"Canadian dollar (CAD)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+1"},
    {key:"ISO 3166 code", value:"CA"},
    {key:"Internal TLD", value:".ca"}
   ];
});

northamericaDataApp.controller('caymanislands-info', function($scope) {
  $scope.info = [
    {key:"Size", value:"264 km2"},
    {key:"Population", value:"61,559 (2017)"},
    {key:"Capital", value:"George Town"},
    {key:"Official Language(s)", value:"English"},
    {key:"Government", value:"Parlimentary, Monarchy"},
    {key:"Monarch", value:"Elizabeth II"},
    {key:"Governer", value:"Martyn Roper"},
    {key:"GDP", value:"$2.507 billion (2014)"},
    {key:"Currency", value:"Cayman Islands dollar (KYD)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+1-345"},
    {key:"ISO 3166 code", value:"KY"},
    {key:"Internal TLD", value:".ky"}
   ];
});

northamericaDataApp.controller('costarica-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Costa Rica"},
    {key:"Size", value:"51,100 km2"},
    {key:"Population", value:"4,999,441 (2018)"},
    {key:"Capital", value:"San José"},
    {key:"Official Language(s)", value:"Spanish"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"Carlos Alvarado"},
    {key:"Vice-president", value:"Epsy Campbell Barr"},
    {key:"GDP", value:"$95.791 billion (2020)"},
    {key:"Currency", value:"Costa Rican colón (CRC)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+506"},
    {key:"ISO 3166 code", value:"CR"},
    {key:"Internal TLD", value:".cr"}
   ];
});

northamericaDataApp.controller('dominica-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Commonwealth of Dominica"},
    {key:"Size", value:"750 km2"},
    {key:"Population", value:"71,625 (2018)"},
    {key:"Capital", value:"Roseau"},
    {key:"Official Language(s)", value:"English"},
    {key:"Government", value:"Parlimentary"},
    {key:"President", value:"Charles Savarin"},
    {key:"Prime minister", value:"Roosevelt Skerrit"},
    {key:"GDP", value:"$688 million (2018)"},
    {key:"Currency", value:"East Caribbean dollar (XCD)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+1-767"},
    {key:"ISO 3166 code", value:"DM"},
    {key:"Internal TLD", value:".dm"}
   ];
});

northamericaDataApp.controller('dominicanrepublic-info', function($scope) {
  $scope.info = [
    {key:"Size", value:"48,671 km2"},
    {key:"Population", value:"10.73 (2018)"},
    {key:"Capital", value:"Santo Domingo"},
    {key:"Official Language(s)", value:"Spanish"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"	Danilo Medina"},
    {key:"Vice-president", value:"	Margarita Cedeño"},
    {key:"GDP", value:"$215.999 billion (2020)"},
    {key:"Currency", value:"Peso (DOP)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+1-809, +1-829, +1-949"},
    {key:"ISO 3166 code", value:"DO"},
    {key:"Internal TLD", value:".do"}
   ];
});

northamericaDataApp.controller('elsalvador-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of El Salvador"},
    {key:"Size", value:"21,041 km2"},
    {key:"Population", value:"6.42 (2018)"},
    {key:"Capital", value:"San Salvador"},
    {key:"Official Language(s)", value:"Spanish"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"	Danilo Medina"},
    {key:"Vice-president", value:"	Margarita Cedeño"},
    {key:"GDP", value:"$53.667 billion (2018)"},
    {key:"Currency", value:"United States dollar (USD)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+503"},
    {key:"ISO 3166 code", value:"SV"},
    {key:"Internal TLD", value:".sv"}
   ];
});

northamericaDataApp.controller('greenland-info', function($scope) {
  $scope.info = [
    {key:"Sovereign state", value:"Kingdom of Denmark"},
    {key:"Size", value:"2,166,086 km2"},
    {key:"Population", value:"55,992 (2019)"},
    {key:"Capital", value:"Nuuk"},
    {key:"Official Language(s)", value:"Greenlandic"},
    {key:"Government", value:"Parlimentary, Monarchy"},
    {key:"Monarch", value:"Margrethe II"},
    {key:"High Commissioner", value:"Mikaela Engell"},
    {key:"Prime Minister", value:"Kim Kielsen"},
    {key:"GDP", value:"$1.8 billion (2011)"},
    {key:"Currency", value:"Danish krone (DKK)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+299"},
    {key:"ISO 3166 code", value:"GL"},
    {key:"Internal TLD", value:".gl"}
   ];
});

northamericaDataApp.controller('grenada-info', function($scope) {
  $scope.info = [
    {key:"Size", value:"348.5 km2"},
    {key:"Population", value:"111,454 (2018)"},
    {key:"Capital", value:"St. George's"},
    {key:"Official Language(s)", value:"English"},
    {key:"Government", value:"Parlimentary, Monarchy"},
    {key:"Monarch", value:"Elizabeth II"},
    {key:"Governer-general", value:"Cécile La Grenade"},
    {key:"Prime minister", value:"Keith Mitchell"},
    {key:"GDP", value:"$215.999 billion (2020)"},
    {key:"Currency", value:"East Caribbean dollar (XCD)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+1-473"},
    {key:"ISO 3166 code", value:"GD"},
    {key:"Internal TLD", value:".gd"}
   ];
});

northamericaDataApp.controller('guatemala-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Guatemala"},
    {key:"Size", value:"108,889 km2"},
    {key:"Population", value:"17.26 million (2018)"},
    {key:"Capital", value:"Guatemala City"},
    {key:"Official Language(s)", value:"Spanish"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"	Alejandro Giammattei"},
    {key:"Vice-president", value:"Guillermo Castillo"},
    {key:"GDP", value:"$145.249 billion (2018)"},
    {key:"Currency", value:"Quetzal (GTQ)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+502"},
    {key:"ISO 3166 code", value:"GT"},
    {key:"Internal TLD", value:".gt"}
   ];
});

northamericaDataApp.controller('haiti-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Haiti"},
    {key:"Size", value:"27,750 km2"},
    {key:"Population", value:"11.12 million (2018)"},
    {key:"Capital", value:"Port-au-Prince"},
    {key:"Official Language(s)", value:"French"},
    {key:"Government", value:"Semi-presidential"},
    {key:"President", value:"Jovenel Moïse"},
    {key:"Prime-minister", value:"Fritz William Michel "},
    {key:"GDP", value:"$19.979 billion (2017)"},
    {key:"Currency", value:"Haitian gourde (HTG)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+509"},
    {key:"ISO 3166 code", value:"HT"},
    {key:"Internal TLD", value:".ht"}
   ];
});

northamericaDataApp.controller('honduras-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Honduras"},
    {key:"Size", value:"112,492 km2"},
    {key:"Population", value:"9.58 million (2018)"},
    {key:"Capital", value:"Tegucigalpa"},
    {key:"Official Language(s)", value:"Spanish"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"Juan Orlando Hernández"},
    {key:"Vice-president", value:"Ricardo Álvarez Arias"},
    {key:"GDP", value:"$49.010 billion (2018)"},
    {key:"Currency", value:"Lempira (HNL)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+504"},
    {key:"ISO 3166 code", value:"HN"},
    {key:"Internal TLD", value:".hn"}
   ];
});

northamericaDataApp.controller('jamaica-info', function($scope) {
  $scope.info = [
    {key:"Size", value:"10,991 km2"},
    {key:"Population", value:"2.89 million (2017)"},
    {key:"Capital", value:"Kingston"},
    {key:"Official Language(s)", value:"English"},
    {key:"Government", value:"Parliamentary, Monarchy"},
    {key:"Monarch", value:"Elizabeth II"},
    {key:"Governor-General", value:"Patrick Allen"},
    {key:"Prime Minister", value:"Andrew Holness"},
    {key:"GDP", value:"$26.981 billion (2018)"},
    {key:"Currency", value:"Jamaican dollar (JMD)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+1-876"},
    {key:"ISO 3166 code", value:"JM"},
    {key:"Internal TLD", value:".jm"}
   ];
});

northamericaDataApp.controller('mexico-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"United Mexican States"},
    {key:"Size", value:"1,972,550 km2"},
    {key:"Population", value:"126.57 million (2019)"},
    {key:"Capital", value:"Mexico City"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"Andrés Manuel López Obrador"},
    {key:"President of the Senate", value:"Mónica Fernández Balboa"},
    {key:"GDP", value:"$2.628 trillion (2019)"},
    {key:"Currency", value:"Peso (MXN)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+52"},
    {key:"ISO 3166 code", value:"MX"},
    {key:"Internal TLD", value:".mx"}
   ];
});

northamericaDataApp.controller('montserrat-info', function($scope) {
  $scope.info = [
    {key:"Size", value:"102 km2"},
    {key:"Population", value:"4,649 (2019)"},
    {key:"Capital", value:"	Plymouth"},
    {key:"Official Language(s)", value:"English"},
    {key:"Government", value:"Parlimentary, Monarchy"},
    {key:"Monarch", value:"Elizabeth II"},
    {key:"Governer", value:"Andrew Pearce"},
    {key:"GDP", value:"$63 million (2014)"},
    {key:"Currency", value:"East Caribbean dollar (XCD)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+1-664"},
    {key:"ISO 3166 code", value:"MS"},
    {key:"Internal TLD", value:".ms"}
   ];
});

northamericaDataApp.controller('nicaragua-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Nicaragua"},
    {key:"Size", value:"130,375 km2"},
    {key:"Population", value:"6.14 million (2012)"},
    {key:"Capital", value:"Managua"},
    {key:"Official Language(s)", value:"Spanish"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"Daniel Ortega"},
    {key:"Vice-president", value:"Rosario Murillo"},
    {key:"GDP", value:"$35.757 billion (2018)"},
    {key:"Currency", value:"Córdoba (NIO)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+505"},
    {key:"ISO 3166 code", value:"NI"},
    {key:"Internal TLD", value:".ni"}
   ];
});

northamericaDataApp.controller('panama-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Panama"},
    {key:"Size", value:"75,417 km2"},
    {key:"Population", value:"4.17 million (2018)"},
    {key:"Capital", value:"Panama City"},
    {key:"Official Language(s)", value:"Spanish"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"Laurentino Cortizo"},
    {key:"Vice-president", value:"Jose Gabriel Carrizo"},
    {key:"GDP", value:"$121.749 billion (2020)"},
    {key:"Currency", value:"Balboa (PAB), United States dollar (USD)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+507"},
    {key:"ISO 3166 code", value:"PA"},
    {key:"Internal TLD", value:".pa"}
   ];
});

northamericaDataApp.controller('puertorico-info', function($scope) {
  $scope.info = [
    {key:"Sovereign state", value:"United States"},
    {key:"Size", value:"9,104 km2"},
    {key:"Population", value:"3.19 million (2018)"},
    {key:"Capital", value:"San Juan"},
    {key:"Official Language(s)", value:"Spanish, English"},
    {key:"Government", value:"Dependency"},
    {key:"Governor", value:"Wanda Vázquez Garced"},
    {key:"Vice-president", value:"Jose Gabriel Carrizo"},
    {key:"GDP", value:"$128.556 billion (2020)"},
    {key:"Currency", value:"United States dollar (USD)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+1 (787)"},
    {key:"ISO 3166 code", value:"PR"},
    {key:"Internal TLD", value:".pr"}
   ];
});

northamericaDataApp.controller('saintkittsnevis-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Federation of Saint Christopher and Nevis"},
    {key:"Size", value:"261 km2"},
    {key:"Population", value:"52,441 (2018)"},
    {key:"Capital", value:"Basseterre"},
    {key:"Official Language(s)", value:"English"},
    {key:"Government", value:"Parlimentary, Monarchy"},
    {key:"Monarch", value:"Elizabeth II"},
    {key:"Governer-general", value:"Sir S.W. Tapley Seaton"},
    {key:"Prime minister", value:"Timothy Harris"},
    {key:"GDP", value:"$1.758 billion (2019)"},
    {key:"Currency", value:"East Caribbean dollar (XCD)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+1-869"},
    {key:"ISO 3166 code", value:"KN"},
    {key:"Internal TLD", value:".kn"}
   ];
});

northamericaDataApp.controller('saintlucia-info', function($scope) {
  $scope.info = [
    {key:"Size", value:"617 km2"},
    {key:"Population", value:"181,889 (2018)"},
    {key:"Capital", value:"Castries"},
    {key:"Official Language(s)", value:"English"},
    {key:"Government", value:"Parlimentary, Monarchy"},
    {key:"Monarch", value:"Elizabeth II"},
    {key:"Governer-general", value:"Neville Cenac"},
    {key:"Prime minister", value:"Allen Chastanet"},
    {key:"GDP", value:"$2.689 billion (2018)"},
    {key:"Currency", value:"East Caribbean dollar (XCD)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+1-758"},
    {key:"ISO 3166 code", value:"LC"},
    {key:"Internal TLD", value:".lc"}
   ];
});

northamericaDataApp.controller('saintpierremiquelon-info', function($scope) {
  $scope.info = [
    {key:"Sovereign state", value:"France"},
    {key:"Size", value:"242 km2"},
    {key:"Population", value:"6,008 (2016)"},
    {key:"Capital", value:"Saint-Pierre"},
    {key:"Official Language(s)", value:"French"},
    {key:"Government", value:"Dependancy"},
    {key:"President of France", value:"Emmanuel Macron"},
    {key:"Prefect", value:"Thierry Devimeux"},
    {key:"Prime minister", value:"Allen Chastanet"},
    {key:"GDP", value:"€161.131 million (2004)"},
    {key:"Currency", value:"Euro (EUR)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+508"},
    {key:"ISO 3166 code", value:"PM"},
    {key:"Internal TLD", value:".pm"}
   ];
});

northamericaDataApp.controller('saintvincentgrenadines-info', function($scope) {
  $scope.info = [
    {key:"Size", value:"389 km2"},
    {key:"Population", value:"110,211 (2018)"},
    {key:"Capital", value:"Kingstown"},
    {key:"Official Language(s)", value:"English"},
    {key:"Government", value:"Parlimentary, Monarchy"},
    {key:"Monarch", value:"Elizabeth II"},
    {key:"Governer-general", value:"Susan Dougan"},
    {key:"Prime minister", value:"Ralph Gonsalves"},
    {key:"GDP", value:"$1.373 billion (2019)"},
    {key:"Currency", value:"East Caribbean dollar (XCD)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+1-784"},
    {key:"ISO 3166 code", value:"VC"},
    {key:"Internal TLD", value:".vc"}
   ];
});

northamericaDataApp.controller('thebahamas-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Commonwealth of The Bahamas"},
    {key:"Size", value:"13,878 km2"},
    {key:"Population", value:"385,637 (2018)"},
    {key:"Capital", value:"Nassau"},
    {key:"Official Language(s)", value:"English"},
    {key:"Government", value:"Parlimentary, Monarchy"},
    {key:"Monarch", value:"Elizabeth II"},
    {key:"Governer-General", value:"Sir Cornelius A. Smith"},
    {key:"Prime minister", value:"Hubert Minnis"},
    {key:"GDP", value:"$12.612 billion (2018)"},
    {key:"Currency", value:"Bahamian dollar (BSD)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+1-242"},
    {key:"ISO 3166 code", value:"BS"},
    {key:"Internal TLD", value:".bs"}
   ];
});

northamericaDataApp.controller('trinidadtobago-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Republic of Trinidad and Tobago"},
    {key:"Size", value:"	5,131 km2"},
    {key:"Population", value:"1.36 million (2019)"},
    {key:"Capital", value:"Port of Spain"},
    {key:"Official Language(s)", value:"English"},
    {key:"Government", value:"Parlimentary"},
    {key:"President", value:"Paula-Mae Weekes"},
    {key:"Prime minister", value:"Keith Rowley"},
    {key:"GDP", value:"	$45.149 billion (2019)"},
    {key:"Currency", value:"Trinidad and Tobago dollar (TTD)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+1 (868)"},
    {key:"ISO 3166 code", value:"TT"},
    {key:"Internal TLD", value:".tt"}
   ];
});

northamericaDataApp.controller('turkscaicos-info', function($scope) {
  $scope.info = [
    {key:"Size", value:"616.3 km2"},
    {key:"Population", value:"31,458 (2012)"},
    {key:"Capital", value:"Cockburn Town"},
    {key:"Official Language(s)", value:"English"},
    {key:"Government", value:"Dependancy, Monarchy"},
    {key:"Monarch", value:"Elizabeth II"},
    {key:"Governer", value:"Nigel Dakin"},
    {key:"Currency", value:"United States dollar (USD)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+1-649)"},
    {key:"ISO 3166 code", value:"TC"},
    {key:"Internal TLD", value:".tc"}
   ];
});

northamericaDataApp.controller('usa-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"United States of America"},
    {key:"Size", value:"9,833,520 km2"},
    {key:"Population", value:"328.23 million (2019)"},
    {key:"Capital", value:"Washington, D.C."},
    {key:"Official Language(s)", value:"English"},
    {key:"Government", value:"Presidential"},
    {key:"President", value:"	Donald Trump"},
    {key:"Vice-president", value:"Mike Pence"},
    {key:"GDP", value:"$21.439 trillion (2019)"},
    {key:"Currency", value:"United States dollar (USD)"},
    {key:"Driving side", value:"Right"},
    {key:"Calling code", value:"+1)"},
    {key:"ISO 3166 code", value:"US"},
    {key:"Internal TLD", value:".us"}
   ];
});

northamericaDataApp.controller('usvirginislands-info', function($scope) {
  $scope.info = [
    {key:"Officially", value:"Virgin Islands of the United States"},
    {key:"Size", value:"346.4 km2"},
    {key:"Population", value:"106,405 (2010)"},
    {key:"Capital", value:"Charlotte Amalie"},
    {key:"Official Language(s)", value:"English"},
    {key:"Government", value:"Dependancy"},
    {key:"President", value:"	Donald Trump"},
    {key:"GDP", value:"$4.58 billion (2015)"},
    {key:"Currency", value:"United States dollar (USD)"},
    {key:"Driving side", value:"Left"},
    {key:"Calling code", value:"+1-340)"},
    {key:"ISO 3166 code", value:"VI"},
    {key:"Internal TLD", value:".vi"}
   ];
});
