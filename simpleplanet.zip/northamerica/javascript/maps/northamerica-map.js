// Themes
am4core.useTheme(am4themes_animated);

// Create map instance
var chart = am4core.create("map", am4maps.MapChart);

// Set map definition
chart.geodata = am4geodata_worldUltra;


// Set projection
chart.projection = new am4maps.projections.Miller();

// Zoom control
chart.zoomControl = new am4maps.ZoomControl();

// Reset Map
var homeButton = new am4core.Button();
homeButton.events.on("hit", function(){
  chart.goHome();
});

homeButton.icon = new am4core.Sprite();
homeButton.padding(7, 5, 7, 5);
homeButton.width = 30;
homeButton.icon.path = "M16,8 L14,8 L14,16 L10,16 L10,10 L6,10 L6,16 L2,16 L2,8 L0,8 L8,0 L16,8 Z M16,8";
homeButton.marginBottom = 10;
homeButton.parent = chart.zoomControl;
homeButton.insertBefore(chart.zoomControl.plusButton);

// Zoom level
chart.homeZoomLevel = 3.5;
chart.homeGeoPoint = { longitude: -95, latitude: 45.5 };


// Asia
var groupData = [
	{ "data": [{"id": "AI", "url": "/north-america/countries/anguilla.html"}] },
	{ "data": [{"id": "AG", "url": "/north-america/countries/antiguabarbuda.html"}] },
	{ "data": [{"id": "AW", "url": "/north-america/countries/aruba.html"}] },
	{ "data": [{"id": "BS", "url": "/north-america/countries/bahamas.html"}] },
	{ "data": [{"id": "BB", "url": "/north-america/countries/barbados.html"}] },
	{ "data": [{"id": "BQ", "url": "/north-america/countries/bonaire.html"}] },
	{ "data": [{"id": "BZ", "url": "/north-america/countries/belize.html"}] },
	{ "data": [{"id": "BM", "url": "/north-america/countries/bermuda.html"}] },
	{ "data": [{"id": "VG", "url": "/north-america/countries/britishvirginislands.html"}] },
	{ "data": [{"id": "CA", "url": "/north-america/countries/canada.html"}] },
	{ "data": [{"id": "KY", "url": "/north-america/countries/caymanislands.html"}] },
	{ "data": [{"id": "CR", "url": "/north-america/countries/costarica.html"}] },
	{ "data": [{"id": "CU", "url": "/north-america/countries/cuba.html"}] },
	{ "data": [{"id": "DM", "url": "/north-america/countries/dominica.html"}] },
	{ "data": [{"id": "CW", "url": "/north-america/countries/curacao.html"}] },
	{ "data": [{"id": "DO", "url": "/north-america/countries/dominicanrepublic.html"}] },
	{ "data": [{"id": "GL", "url": "/north-america/countries/greenland.html"}] },
	{ "data": [{"id": "GP", "url": "/north-america/countries/guadeloupe.html"}] },
	{ "data": [{"id": "GD", "url": "/north-america/countries/grenada.html"}] },
	{ "data": [{"id": "GT", "url": "/north-america/countries/guatemala.html"}] },
	{ "data": [{"id": "HT", "url": "/north-america/countries/haiti.html"}] },
	{ "data": [{"id": "HN", "url": "/north-america/countries/honduras.html"}] },
	{ "data": [{"id": "JM", "url": "/north-america/countries/jamaica.html"}] },
	{ "data": [{"id": "MX", "url": "/north-america/countries/mexico.html"}] },
	{ "data": [{"id": "MS", "url": "/north-america/countries/montserrat.html"}] },
	{ "data": [{"id": "MQ", "url": "/north-america/countries/martinique.html"}] },
	{ "data": [{"id": "NI", "url": "/north-america/countries/nicaragua.html"}] },
	{ "data": [{"id": "BL", "url": "/north-america/countries/saintbarthelemy.html"}] },
	{ "data": [{"id": "KN", "url": "/north-america/countries/saintkittsnevis.html"}] },
	{ "data": [{"id": "LC", "url": "/north-america/countries/saintlucia.html"}] },
	{ "data": [{"id": "MF", "url": "/north-america/countries/saintmartin.html"}] },
	{ "data": [{"id": "PM", "url": "/north-america/countries/saintpierremiquelon.html"}] },
	{ "data": [{"id": "VC", "url": "/north-america/countries/saintvincentgrenadines.html"}] },
	{ "data": [{"id": "VI", "url": "/north-america/countries/usvirginislands.html"}] },
	{ "data": [{"id": "TT", "url": "/north-america/countries/trinidadtobago.html"}] },
	{ "data": [{"id": "SV", "url": "/north-america/countries/elsalvador.html"}] },
	{ "data": [{"id": "PR", "url": "/north-america/countries/puertorico.html"}] },
	{ "data": [{"id": "PA", "url": "/north-america/countries/panama.html"}] },
	{ "data": [{"id": "US", "url": "/north-america/countries/us.html"}] },
  { "data": [{"id": "WF"}] },
  { "data": [{"id": "TC"}] }
	];


var excludedCountries = ["AQ"];


groupData.forEach(function(group) {
  var series = chart.series.push(new am4maps.MapPolygonSeries());
  series.name = group.name;
  series.useGeodata = true;
  var includedCountries = [];
  group.data.forEach(function(country){
    includedCountries.push(country.id);
    excludedCountries.push(country.id);
  });
  series.include = includedCountries;

  series.fill = am4core.color("#c3d6a9");


  series.setStateOnChildren = true;
  var seriesHoverState = series.states.create("hover");


  var mapPolygonTemplate = series.mapPolygons.template;
  mapPolygonTemplate.fill = am4core.color("#a1d47f");
  mapPolygonTemplate.fillOpacity = 1;
  mapPolygonTemplate.nonScalingStroke = false;
  mapPolygonTemplate.stroke = am4core.color("#000");
  mapPolygonTemplate.strokeWidth = 0.1;
  mapPolygonTemplate.strokeOpacity = 0.5;
  mapPolygonTemplate.tooltipText = "{name}";
  mapPolygonTemplate.propertyFields.url = "url";

  var hoverState = mapPolygonTemplate.states.create("hover");
  hoverState.properties.fill = am4core.color("#8ec16c");


  series.data = JSON.parse(JSON.stringify(group.data));
});


// The rest of the world.
var worldSeries = chart.series.push(new am4maps.MapPolygonSeries());
var worldSeriesName = "world";
worldSeries.name = worldSeriesName;
worldSeries.useGeodata = true;
worldSeries.exclude = excludedCountries;
worldSeries.fillOpacity = 1;
worldSeries.mapPolygons.template.nonScalingStroke = true;

worldSeries.mapPolygons.template.stroke = worldSeries.mapPolygons.template.fill;
worldSeries.mapPolygons.template.strokeWidth = 0;
